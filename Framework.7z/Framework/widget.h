#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

enum PluginManagerType
{
    PluginManager_None = 0,
    PluginManager_Qt = 1,
    PluginManager_Web,
    PluginManager_Log,
};

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    ///
    /// \brief 初始化标题栏
    ///
    void initTitleBar();

    ///
    /// \brief 延迟启动
    ///
    void delayStart();

    ///
    /// \brief 点击插件管理按钮
    ///
    void on_PluginManageBtn_clicked();

    ///
    /// \brief 插件管理菜单点击
    ///
    void slotManagerMenuClicked();

    ///
    /// \brief 初始化插件管理菜单及其页面
    /// \param type 类型
    /// \param name_en 标签英文名称
    /// \param name_ch 标签中文名称
    ///
    void initPluginManagerTab(int type, const QString& name_en, const QString& name_ch);

private:
    Ui::Widget *ui;
};
#endif // WIDGET_H
