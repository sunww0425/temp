/*****************************************************
** 文件名：OpenPluginStruct.h
** 版 本：v.1.0
** 内容简述：打开的插件界面结构体
** 创建人：孙伟伟
** 修改记录：1.0
日期:2026.02.09  版本:v.1.0    修改人:孙伟伟   修改内容:创建
*****************************************************/
#ifndef OPENPLUGINSTRUCT_H
#define OPENPLUGINSTRUCT_H



#include <QString>
#include <QUuid>
#include <QDomElement>
#include <QTextCodec>
#include <QDomDocument>
#include <QIcon>
#include <QDir>
#include <QFile>
#include <QTextStream>

/**
 * @brief 插件类型枚举
 * 定义不同类型的插件分类，用于区分插件的实现技术栈
 */
enum PluginType{
    Plugin_Type_Undef = -1,  // 未定义/未知类型（默认值）
    Plugin_Type_Qt = 0,      // Qt原生插件（基于Qt框架开发）
    PLugin_Type_Web         // Web插件（基于网页技术开发）
};

/**
 * @brief 插件状态枚举
 * 标识插件当前的运行状态
 */
enum PluginState{
    Plugin_State_Stopped = 0,  // 禁用状态（默认值）
    Plugin_State_Started       // 启用状态
};

/**
 * @brief 插件加载模式枚举
 * 定义插件的运行加载方式
 */
enum PluginLoadMode{
    Plugin_Load_Orinal = 0,  // 原生模式（主进程内加载）
    Plugin_Load_App          // 独立进程模式（插件在单独进程中运行）
};

/**
 * @brief 插件嵌入布局模式枚举
 * 定义插件UI嵌入到主界面时的布局方式
 */
enum PluginEmbededMode{
    Plugin_Embed_AutoLayout = 0,   // 自动布局（由系统管理插件位置）
    Plugin_Embed_ManualLayout      // 手动布局（用户自定义插件位置）
};

/**
 * @brief 插件信息结构体
 * 存储插件的所有核心配置信息，支持XML序列化/反序列化
 */
struct OpenPluginStruct
{
    QString id;             // 插件唯一标识（全局唯一，不可重复）
    QString name;           // 插件显示名称（界面展示用）
    PluginState state;      // 插件当前状态（启用/禁用）
    PluginType type;        // 插件类型（Qt/Web）
    QString icon_path;      // 插件自定义图标路径
    QString url;            // 插件加载路径
    QString version;        // 插件版本号（如：1.0.0）
    QString describe;       // 插件描述信息（功能说明）
    int index;              // 插件展示顺序索引（用于界面按钮排序）

    /**
     * @brief 重载相等运算符，判断两个插件信息是否相同
     * @param obj 待比较的插件信息对象
     * @return 比较结果：ID和名称都相同则返回true，否则返回false
     */
    inline bool operator==(const OpenPluginStruct &obj)
    {
        if(obj.id==id && obj.name==name)
        {
            return true;
        }
        return false;
    }

    /**
     * @brief 默认构造函数
     * 初始化插件类型为未定义，状态为禁用（默认值）
     */
    OpenPluginStruct()
    {
        type = Plugin_Type_Undef;
        state = Plugin_State_Stopped;
    }

    /**
     * @brief 从XML节点构造插件信息
     * @param ele 存储插件信息的XML元素节点
     */
    OpenPluginStruct(const QDomElement& ele);

    /**
     * @brief 获取插件类型的字符串描述
     * @return 类型字符串（如："Qt插件"、"Web插件"等）
     */
    QString getTypeString() const;

    /**
     * @brief 获取插件状态的字符串描述
     * @return 状态字符串（如："启用"、"禁用"）
     */
    QString getStateString() const;

    /**
     * @brief 获取插件状态的数字字符串描述
     * @return 状态数字字符串（如："0"表示禁用，"1"表示启用）
     */
    QString getStateNumString()const;

    /**
     * @brief 将插件信息序列化为XML字符串
     * @return 包含插件信息的XML格式字符串
     */
    virtual QString toXml() const;

    /**
     * @brief 将插件信息更新到指定的XML元素节点
     * @param ele 待更新的XML元素节点指针
     */
    virtual void update2Element(QDomElement* ele);

    /**
     * @brief 获取用于XML查找的ID字符串
     * @return 适配XML查询的ID字符串（用于定位插件节点）
     */
    QString getXmlIdSearchString();

    /**
     * @brief 获取插件类型的XML存储字符串
     * @return 用于XML保存的插件类型字符串
     */
    QString getXmlTypeString();

    /**
     * @brief 调整插件图标路径为有效路径
     * 检查并修正图标路径，确保路径有效（如相对路径转绝对路径）
     * @return 路径调整成功返回true，失败返回false
     */
    bool adjustIconPath();
};

/**
 * @brief 将插件信息列表保存到XML文件
 * @tparam T 插件信息类型（需继承OpenPluginStruct并实现toXmlElement方法）
 * @param fileName XML文件保存路径
 * @param list 待保存的插件信息列表
 * @param errorMsg 输出参数，保存失败时返回错误信息
 * @return 保存成功返回true，失败返回false
 */
template<typename T>
bool savePluginInfoToXmlFile(const QString& fileName, const QList<T>& list, QString& errorMsg)
{
    // 获取文件所在目录路径
    int index = fileName.lastIndexOf("/");
    if(index > 0)
    {
        QString directory = fileName.left(index);
        if(directory.size() > 0)
        {
            QDir dir(directory);
            // 检查目录是否存在，不存在则创建
            if((!dir.exists()) && (!dir.mkpath(directory)))
            {
                errorMsg = QStringLiteral("保存插件信息出错.创建保存目录失败:%1").arg(directory);
                return false;
            }
        }
    }

    // 打开文件（覆盖写入模式）
    QFile file(fileName);
    if(!file.open(QIODevice::WriteOnly| QIODevice::Text | QIODevice::Truncate))
    {
        errorMsg = QStringLiteral("保存插件信息出错.打开保存文件失败:%1").arg(fileName);
        return false;
    }

    // 构建XML文档结构
    QDomDocument doc;
    QDomElement root =  doc.createElement("plugins");
    doc.appendChild(root);

    // 将每个插件信息添加到XML根节点
    for(int i=0; i<list.size(); i++)
    {
        T info = list[i];
        info.doc = &doc;
        root.appendChild(info.toXmlElement());
    }

    // 写入并保存XML文件（UTF-8编码，缩进4个字符）
    QTextStream ts(&file);
    ts.setCodec(QTextCodec::codecForName("UTF-8"));
    doc.save(ts, 4, QDomNode::EncodingFromTextStream);
    file.close();
    return true;
}

/**
 * @brief 从XML文件加载插件信息到映射表
 * @tparam T 插件信息类型（需支持从QDomElement构造）
 * @param fileName XML文件路径
 * @param map 输出参数，加载后的插件信息映射表（key:插件ID，value:插件信息）
 * @param errorMsg 输出参数，加载失败时返回错误信息
 * @return 加载成功返回true，失败返回false
 */
template<typename T>
bool initPluginInfoFromXmlFile(const QString& fileName, QMap<QString, T>& map, QString& errorMsg)
{
    map.clear(); // 清空原有数据

    // 打开XML文件（只读模式）
    QFile file(fileName);
    if(!file.open(QIODevice::ReadOnly))
    {
        errorMsg = QStringLiteral("读取插件信息出错.打开保存文件失败:%1").arg(fileName);
        return false;
    }

    // 解析XML内容
    QDomDocument doc;
    if(!doc.setContent(&file))
    {
        file.close();
        errorMsg = QStringLiteral("读取插件信息出错.转换文件xml错误:%1").arg(fileName);
        return false;
    }
    file.close();

    // 遍历XML节点，加载所有插件信息
    QDomElement docElem = doc.documentElement();
    QDomNode n = docElem.firstChild();
    while(!n.isNull())
    {
        QDomElement e = n.toElement();
        T info(e);
        map.insert(info.id, info); // 按插件ID插入映射表
        n=n.nextSibling();
    }
    return true;
}

/**
 * @brief 从XML节点列表解析插件信息到列表
 * @tparam T 插件信息类型（需支持从QDomElement构造）
 * @param nodes XML节点列表（包含多个插件信息节点）
 * @param list 输出参数，解析后的插件信息列表
 */
template<typename T>
void parsePluginFromXmlNodeList(const QDomNodeList& nodes, QList<T>& list)
{
    for(int i=0; i<nodes.size(); i++)
    {
        QDomElement ele = nodes.at(i).toElement();
        if(ele.isNull()) continue; // 跳过无效节点

        // 添加插件信息并设置展示顺序索引
        list.append(T(ele));
        list.last().index = i;
    }
}

#endif // OPENPLUGINSTRUCT_H
