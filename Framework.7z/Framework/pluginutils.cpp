﻿/*****************************************************
** 文件名：PluginUtils.cpp
** 版 本：v.1.0
** 内容简述：QT插件工具类
** 创建人：孙伟伟
** 修改记录：1.0
日期:2026.02.09  版本:v.1.0    修改人:孙伟伟   修改内容:创建
*****************************************************/

#include "pluginutils.h"
#include <QDir>
#include <QPixmap>
#include <QApplication>
#include <QBuffer>
#include <QDebug>

PluginUtils::PluginUtils()
{

}

void PluginUtils::questionMsgBox(const QString& text, const QString& title)
{
    messageBox(QMessageBox::Question, title, text);
}

void PluginUtils::informationMsgBox(const QString& text, const QString& title)
{
    messageBox(QMessageBox::Information, title, text);
}

void PluginUtils::errorMsgBox(const QString& text, const QString& title)
{
    messageBox(QMessageBox::Critical, title, text);
}

void PluginUtils::warningMsgBox(const QString& text, const QString& title)
{
    messageBox(QMessageBox::Warning, title, text);
}


void PluginUtils::messageBox(QMessageBox::Icon type, const QString &title, const QString &text)
{
    switch (type)
    {
    case QMessageBox::Warning:
        QMessageBox::warning(NULL, title , text, QStringLiteral("确认"));
        break;
    case QMessageBox::Critical:
        QMessageBox::critical(NULL, title , text, QStringLiteral("确认"));
        break;
    case QMessageBox::Information:
        QMessageBox::critical(NULL, title , text, QStringLiteral("确认"));
        break;
    case QMessageBox::Question:
        QMessageBox::critical(NULL, title , text, QStringLiteral("确认"));
        break;
    default:
        break;
    }
}

MessageOption PluginUtils::errorMsgBoxWithOption(const QString& text, const QString& title )
{
    return messageBoxWithOption(QMessageBox::Critical, title, text);
}

MessageOption PluginUtils::warningMsgBoxWithOption(const QString& text, const QString& title )
{
    return messageBoxWithOption(QMessageBox::Warning, title, text);
}

MessageOption PluginUtils::informationMsgBoxWithOption(const QString& text, const QString& title )
{
    return messageBoxWithOption(QMessageBox::Information, title, text);
}

MessageOption PluginUtils::questionMsgBoxWithOption(const QString& text, const QString& title )
{
    return messageBoxWithOption(QMessageBox::Question, title, text);
}


MessageOption PluginUtils::messageBoxWithOption(QMessageBox::Icon type, const QString &title, const QString &text)
{
    int opt = Msg_None;
    switch (type) {
    case QMessageBox::Warning:
        opt = QMessageBox::warning(NULL, title , text, QStringLiteral("是"), QStringLiteral("否"));
        break;
    case QMessageBox::Critical:
        opt = QMessageBox::critical(NULL, title , text, QStringLiteral("是"), QStringLiteral("否"));
        break;
    case QMessageBox::Information:
        opt = QMessageBox::information(NULL, title , text, QStringLiteral("是"), QStringLiteral("否"));
        break;
    case QMessageBox::Question:
        opt = QMessageBox::question(NULL, title , text, QStringLiteral("是"), QStringLiteral("否"));
        break;
    default:
        break;
    }

    return MessageOption(opt);
}

bool PluginUtils::savePluginNativeIcon(const QByteArray &bytes, const QString &id, QString& savePath)
{
    QString destDirPath = QString("Images/NativeIcon");
    QDir destDir(destDirPath);
    if(!destDir.exists())
    {
        QDir(QApplication::applicationDirPath()).mkpath(destDirPath);
    }
    savePath = QString("%1/%2.png").arg(destDirPath).arg(id);
    QPixmap img;
    img.loadFromData(bytes, "png");
    return img.save(QString("%1/%2").arg(QApplication::applicationDirPath()).arg(savePath), "png");
}

QString PluginUtils::getFullIconPath(const QString &path)
{
    if(path.startsWith("Images"))
    {
        return QString("%1/%2").arg(QApplication::applicationDirPath()).arg(path);
    }
    return path;
}

QString PluginUtils::getPluginNativeIcon(const QString &id)
{
    QString destImage = QString("Images/NativeIcon/%1.png").arg(id);
    if(QFile::exists(getFullIconPath(destImage))) return destImage;
    return QString();
}

bool PluginUtils::savePluginNativeIcon(const QIcon &icon, const QString &id, QString &savePath)
{
    QList<QSize> list = icon.availableSizes();
    if(list.size() == 0) return false;
    QPixmap img = icon.pixmap(list.first(), QIcon::Normal, QIcon::On);
    QByteArray bytes;
    QBuffer buffer(&bytes);
    if(!buffer.open(QIODevice::WriteOnly)) return false;
    bool sts = img.save(&buffer, "png");
    if(sts)
    {
        sts = savePluginNativeIcon(bytes, id, savePath);
    }
    buffer.close();
    return sts;
}

bool PluginUtils::copyLauncherLibPath(const QString &libpath, const QString& id, QString& destFile)
{
    QString workPath = libpath;
    if(!workPath.contains("Plugins"))
    {
        workPath.insert(0, "Plugins/");
    }
    QFileInfo info(workPath);

    destFile = QString("%1/%2.exe").arg(info.absoluteDir().path()).arg(id);
    {
        QFile::copy("PluginLauncher.exe", destFile);
        //生成对应的Qt目录指定
        QString qt_config_file =  QString("%1/qt.conf").arg(info.absoluteDir().path());
        QFile file(qt_config_file);
        if(file.open(QIODevice::WriteOnly))
        {
            file.write("[Paths]\n");
            file.write(QString("Prefix=%1").arg(qApp->applicationDirPath()).toStdString().data());
            file.write("Plugins=qtplugins\n");
            file.close();
        }
        return QFile::exists(destFile);
    }
    return true;
}
