﻿/*****************************************************
** 文件名：OpenPluginStruct.cpp
** 版 本：v.1.0
** 内容简述：打开的插件界面结构体
** 创建人：孙伟伟
** 修改记录：1.0
日期:2026.02.09  版本:v.1.0    修改人:孙伟伟   修改内容:创建
*****************************************************/

#include "openpluginstruct.h"
#include <QDir>
#include <QDateTime>
#include <QBuffer>
#include <QDebug>
#include "pluginutils.h"

/**
 * @brief 获取插件状态的文字描述
 * @return 状态字符串："启用"（已启动）、"禁用"（已停止）、"状态未定义"（未知状态）
 */
QString OpenPluginStruct::getStateString() const
{
    if(state == Plugin_State_Started) return QStringLiteral("启用");
    if(state == Plugin_State_Stopped) return QStringLiteral("禁用");
    return QStringLiteral("状态未定义");
}

/**
 * @brief 获取插件状态的数字字符串表示
 * 用于XML存储或数值比较，与PluginState枚举值一一对应
 * @return 状态数字字符串："1"（启用）、"0"（禁用）、"-1"（未知状态）
 */
QString OpenPluginStruct::getStateNumString() const
{
    if(state == Plugin_State_Started) return QStringLiteral("1");
    if(state == Plugin_State_Stopped) return QStringLiteral("0");
    return QStringLiteral("-1");
}

/**
 * @brief 获取插件类型的文字描述（简化标识）
 * @return 类型字符串："GUI"（Qt插件）、"WEB"（Web插件）、"ThirdApp"（第三方应用）、"类型未定义"（未知类型）
 */
QString OpenPluginStruct::getTypeString() const
{
    if(type == Plugin_Type_Qt) return QStringLiteral("GUI");
    if(type == PLugin_Type_Web) return QStringLiteral("WEB");
    return QStringLiteral("类型未定义");
}

/**
 * @brief 将插件信息序列化为XML字符串（单标签格式）
 * 拼接插件所有核心属性为XML的Plugin节点字符串，属性包含名称、路径、状态、描述等
 * @return 包含插件信息的XML字符串片段
 * @note 注意：此实现存在语法小问题（标签末尾多了空格），建议后续优化
 */
QString OpenPluginStruct::toXml() const
{
    return QStringLiteral("<Plugin ")
            + QStringLiteral(" name=\"%1\"").arg(name)      // 插件名称属性
            + QStringLiteral(" url=\"%1\"").arg(url)        // 插件加载路径/地址属性
            + QStringLiteral(" state=\"%1\"").arg(state)    // 插件状态（数字值）属性
            + QStringLiteral(" describe=\"%1\"").arg(describe) // 插件描述属性
            + QStringLiteral(" version=\"%1\"").arg(version)   // 插件版本属性
            + QStringLiteral(" id=\"%1\"").arg(id)          // 插件唯一ID属性
            + QStringLiteral(" icon=\"%1\"").arg(icon_path) // 插件图标路径属性
            + QStringLiteral(" </Plugin>");                 // 标签闭合（注意：此处多了一个空格）
}

/**
 * @brief 获取插件类型对应的XML节点名称
 * 用于区分不同类型插件的XML父节点，适配XML解析逻辑
 * @return 插件类型对应的XML节点名："ExEPlugin"（第三方应用）、"DllPlugin"（Qt插件）、"WebPlugin"（Web插件），未知类型返回空字符串
 */
QString OpenPluginStruct::getXmlTypeString()
{
    QString key;
    if(type == Plugin_Type_Qt)
    {
        key = "DllPlugin";       // Qt插件对应XML节点名
    }
    else if(type == PLugin_Type_Web)
    {
        key = "WebPlugin";       // Web插件对应XML节点名
    }
    return key;
}

/**
 * @brief 生成用于XML查找的XPath表达式
 * 用于快速定位当前插件在XML文档中的节点位置
 * @return XPath字符串（格式：//类型节点/Plugin[@id='插件ID']），类型未知时返回空字符串
 */
QString OpenPluginStruct::getXmlIdSearchString()
{
    QString type = getXmlTypeString();
    if(type.size() > 0)
    {
        // 拼接XPath表达式，通过插件类型+ID精准定位XML节点
        return QString("//%1/Plugin[@id='%2']").arg(type).arg(id);
    }
    return QString();
}

/**
 * @brief 将插件信息更新到指定的XML元素节点
 * 覆盖或设置XML节点的属性值，确保节点与插件信息同步
 * @param ele 待更新的XML元素节点指针（为空则直接返回）
 */
void OpenPluginStruct::update2Element(QDomElement* ele)
{
    if(!ele)
    {
        return; // 空指针保护，避免崩溃
    }
    // 确保节点标签名为"Plugin"，不一致则强制修改
    if(ele->tagName() != "Plugin") ele->setTagName("Plugin");

    // 逐一设置插件属性到XML节点
    ele->setAttribute("id", id);          // 唯一ID
    ele->setAttribute("name", name);      // 插件名称
    ele->setAttribute("icon", icon_path); // 图标路径
    ele->setAttribute("url", url);        // 加载路径/地址
    ele->setAttribute("version", version);// 版本号
    ele->setAttribute("describe", describe); // 描述信息
    ele->setAttribute("state", state);    // 状态（数字值）
}

/**
 * @brief 从XML元素节点构造插件信息
 * 解析XML节点的属性值，初始化插件结构体的成员变量
 * @param ele 包含插件信息的XML元素节点
 */
OpenPluginStruct::OpenPluginStruct(const QDomElement &ele)
{
    // 从XML属性中读取并初始化插件核心信息
    id = ele.attribute("id");
    name = ele.attribute("name");
    icon_path = ele.attribute("icon");
    url = ele.attribute("url");
    version = ele.attribute("version");
    describe = ele.attribute("describe");
    // 将字符串类型的状态值转换为PluginState枚举类型
    state = (PluginState)(ele.attribute("state").toInt());
}

/**
 * @brief 调整插件图标路径为当前运行目录下的相对路径
 * 处理资源路径转换、默认图标补全逻辑，确保图标路径有效
 * @return 路径是否发生修改：true（已调整）、false（未调整）
 */
bool OpenPluginStruct::adjustIconPath()
{
    bool changed = false; // 标记路径是否被修改
    if(icon_path.size() > 0)
    {
        // 处理Qt资源路径（:/开头）：转换为本地Images目录相对路径
        if(icon_path.startsWith(":/"))
        {
            // 将资源路径前缀":/Image"替换为本地目录"Images"
            icon_path.replace(":/Image", "Images");
            changed = true;
        }
    }
    else
    {
        // 图标路径为空时，尝试获取插件原生图标路径
        icon_path = PluginUtils::getPluginNativeIcon(id);
        if(icon_path.size() == 0)
        {
            // 原生图标不存在时，按插件类型设置默认图标
            if(type == PLugin_Type_Web)
            {
                icon_path = QString("Images/WebPlugin.png");    // Web插件默认图标
            }
            else if(type == Plugin_Type_Qt)
            {
                icon_path =  QString("Images/QTPlugin.png");    // Qt插件默认图标
            }
            else
            {
                icon_path =  QString("Images/Defalult.png");    // 其他类型默认图标（注意：Defalult拼写错误，应为Default）
            }
        }
        changed = true; // 空路径补全后标记为已修改
    }

    return changed;
}
