/*****************************************************
** 文件名：PluginUtils.h
** 版 本：v.1.0
** 内容简述：QT插件工具类
** 创建人：孙伟伟
** 修改记录：1.0
日期:2026.02.09  版本:v.1.0    修改人:孙伟伟   修改内容:创建
*****************************************************/
#ifndef PLUGINUTILS_H
#define PLUGINUTILS_H

#include <QMessageBox>
#include <QIcon>

/**
 * @brief 消息框操作选项枚举
 * 用于标识用户在带选项的消息框中点击的按钮类型
 */
enum MessageOption{
    Msg_None= -1,      ///< 无操作/未选择
    Msg_Continue = 0,  ///< 继续/确认操作
    Msg_Cancel = 1     ///< 取消操作
};

/**
 * @brief 插件工具类
 * 提供插件开发中常用的通用功能，包括消息框显示、图标保存/读取、文件拷贝等
 * 所有方法均为静态方法，无需实例化即可使用
 */
class PluginUtils
{
public:
    /**
     * @brief 构造函数
     * 由于所有功能均为静态方法，此类无需实例化，构造函数仅为语法兼容保留
     */
    PluginUtils();

    /**
     * @brief 通用消息框显示方法
     * @param type 消息框图标类型（提示、警告、错误、询问等）
     * @param title 消息框标题
     * @param text 消息框显示的内容文本
     */
    static void messageBox(QMessageBox::Icon type, const QString& title, const QString& text);

    /**
     * @brief 快捷显示警告消息框
     * @param text 警告内容文本
     * @param title 消息框标题，默认值为"警告"
     */
    static void warningMsgBox(const QString& text, const QString& title = QStringLiteral("警告"));

    /**
     * @brief 快捷显示通知消息框
     * @param text 通知内容文本
     * @param title 消息框标题，默认值为"通知"
     */
    static void informationMsgBox(const QString& text, const QString& title = QStringLiteral("通知"));

    /**
     * @brief 快捷显示错误消息框
     * @param text 错误内容文本
     * @param title 消息框标题，默认值为"错误"
     */
    static void errorMsgBox(const QString& text, const QString& title = QStringLiteral("错误"));

    /**
     * @brief 快捷显示询问消息框
     * @param text 询问内容文本
     * @param title 消息框标题，默认值为"询问"
     */
    static void questionMsgBox(const QString& text, const QString& title = QStringLiteral("询问"));

    /**
     * @brief 显示带操作选项的警告消息框
     * @param text 警告内容文本
     * @param title 消息框标题，默认值为"警告"
     * @return 返回用户选择的操作选项（继续/取消）
     */
    static MessageOption warningMsgBoxWithOption(const QString& text, const QString& title = QStringLiteral("警告"));

    /**
     * @brief 显示带操作选项的通知消息框
     * @param text 通知内容文本
     * @param title 消息框标题，默认值为"通知"
     * @return 返回用户选择的操作选项（继续/取消）
     */
    static MessageOption informationMsgBoxWithOption(const QString& text, const QString& title = QStringLiteral("通知"));

    /**
     * @brief 显示带操作选项的错误消息框
     * @param text 错误内容文本
     * @param title 消息框标题，默认值为"错误"
     * @return 返回用户选择的操作选项（继续/取消）
     */
    static MessageOption errorMsgBoxWithOption(const QString& text, const QString& title = QStringLiteral("错误"));

    /**
     * @brief 显示带操作选项的询问消息框
     * @param text 询问内容文本
     * @param title 消息框标题，默认值为"询问"
     * @return 返回用户选择的操作选项（继续/取消）
     */
    static MessageOption questionMsgBoxWithOption(const QString& text, const QString& title = QStringLiteral("询问"));

    /**
     * @brief 通用带操作选项的消息框显示方法
     * @param type 消息框图标类型
     * @param title 消息框标题
     * @param text 消息框显示的内容文本
     * @return 返回用户选择的操作选项（继续/取消/无操作）
     */
    static MessageOption messageBoxWithOption(QMessageBox::Icon type, const QString& title, const QString& text);

    /**
     * @brief 从字节数组保存插件原生图标到文件
     * @param bytes 图标数据的字节数组
     * @param id 插件唯一标识（用于生成图标文件名）
     * @param savePath 输出参数，保存成功后返回图标文件的完整路径
     * @return 保存成功返回true，失败返回false
     */
    static bool savePluginNativeIcon(const QByteArray& bytes, const QString& id, QString& savePath);

    /**
     * @brief 从QIcon对象保存插件原生图标到文件
     * @param icon QIcon图标对象
     * @param id 插件唯一标识（用于生成图标文件名）
     * @param savePath 输出参数，保存成功后返回图标文件的完整路径
     * @return 保存成功返回true，失败返回false
     */
    static bool savePluginNativeIcon(const QIcon &icon, const QString &id, QString &savePath);

    /**
     * @brief 获取插件原生图标路径
     * @param id 插件唯一标识
     * @return 返回插件图标文件的路径，如果不存在则返回空字符串
     */
    static QString getPluginNativeIcon(const QString& id);

    /**
     * @brief 获取图标的完整路径
     * @param path 图标相对路径或文件名
     * @return 返回图标文件的绝对完整路径
     */
    static QString getFullIconPath(const QString& path);

    /**
     * @brief 将启动器文件拷贝到插件库目录
     * @param libpath 插件库目标目录路径
     * @param id 插件唯一标识（用于生成目标文件名）
     * @param destFile 输出参数，拷贝成功后返回目标文件的完整路径
     * @return 拷贝成功返回true，失败返回false
     */
    static bool copyLauncherLibPath(const QString& libpath, const QString& id, QString& destFile);

};

#endif // PLUGINUTILS_H
