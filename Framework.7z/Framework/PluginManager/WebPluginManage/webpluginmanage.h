﻿/*****************************************************
** 文件名：WebPluginManage.h
** 版 本：v.1.0
** 内容简述：Web插件管理类
** 创建日期： 2021.11.17
** 创建人：孙伟伟
** 修改记录：1.0
日期:2021.11.17  版本:v.1.0    修改人:孙伟伟   修改内容:创建
*****************************************************/
#ifndef WEBPLUGINMANAGE_H
#define WEBPLUGINMANAGE_H

#include <QObject>
#include <QWidget>
#include "WebPluginManage/WebPluginInfo.h"
#include <QMutex>
#include <QMap>
#include "FunctionPage/applauncher.h"

//enum WebPluginLoadMode{
//    WidgetLoad = 0,     //内部加载
//    ExeLoad,         //外部独立进程加载
//};

class WebPluginManage : public QObject
{
    Q_OBJECT
private:
    explicit WebPluginManage(QObject *parent = nullptr);
public:
    static WebPluginManage* instance();
    void setPluginLoadMode(int mode) {mLoadMode = mode;}
    int getPluginLoadMode() {return mLoadMode;}
    void setIsAboutExit(bool sts) {mIsAboutExit = sts;}
    void stop();
    bool addPlugin(const WebPluginStruct& info, QString& errorMsg);
    bool modifyPlugin(const WebPluginStruct& info, QString& errorMsg);
    bool deletePlugin(const QString& id, QString& errorMsg);
    bool updatePluginState(const QString& id, PluginState state, QString& errorMsg);
    QList<WebPluginStruct> getPluginList() {return mPluginMap.values();}
    bool startPlugin(const QString& id, QString& errorMsg);
    bool stopPlugin(const QString& id, QString& errorMsg);
    bool getPluginWithId(const QString& id, WebPluginStruct& info);
    bool isPluginIdExist(const QString& id);
    void reloadPluginWindow(const QString &id);
private:
    bool startPluginWithLauncher(const WebPluginStruct &plugin);
    void appendLauncher(const QString &id, AppLauncher *launcher);
    void removeLanuncher(const QString &id);
    AppLauncher* getLauncherOfId(const QString &id);
    QStringList getAllLaunchers();
private slots:
    //接收到插件启动器返回的插件窗口id
    void slotRecvPluginWId(const QString &pluginId, qint64 wid);
    //接收到插件程序结束的情况
    void slotRecvPluginLauncherEnd(const QString &id);

signals:
    //发送到插件编辑管理界面的信号
    void signalEditPluginSuccess(const WebPluginStruct& info);
    void signalDelPluginSuccess(const QString& id);
    void signalSendPluginList(const QList<WebPluginStruct>& list);
    //发送到插件主界面的信号
    void signalPluginInitFinished();
    void signalStartPlugin(const WebPluginStruct& plugin, qint64 wid = 0);
    void signalStopPlugin(const QString& id);

public slots:
    void slotLoadPluginList(const QList<WebPluginStruct>& list);
private:
    //修复配置文件存在的资源使用
    void repairIconResourcePath();

protected:
private:
    static WebPluginManage*              mInstance;
    static QMutex                               mInsMutex;

    QMap<QString, WebPluginStruct> mPluginMap;
    QMutex                                        mDataMutex;
    int                                                 mLoadMode = Plugin_Load_Orinal;
    // 插件独立运行相关
    QMap<QString, AppLauncher*>        mPluginLauncherMap;
    QMutex                                                        mLauncherMutex;
    //
    bool                                                              mIsAboutExit = false;
    //插件加载模式
};

#endif // WEBPLUGINMANAGE_H
