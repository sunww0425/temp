﻿/*****************************************************
** 文件名：EditWebPluginGUI.h
** 版 本：v.1.0
** 内容简述：编辑Web插件界面
** 创建日期： 2021.11.17
** 创建人：孙伟伟
** 修改记录：1.0
日期:2021.11.17  版本:v.1.0    修改人:孙伟伟   修改内容:创建
*****************************************************/
#include "editwebplugingui.h"
#include "ui_editwebplugingui.h"
#include <QMessageBox>
#include <QMouseEvent>
#include <QFileDialog>

EditWebPluginGUI::EditWebPluginGUI(QWidget *parent) :
    BaseWindow(parent),
    ui(new Ui::EditWebPluginGUI)
{
    ui->setupUi(this);
    ///初始化标题栏
    initTitleBar();
    ui->lineEdit_Id->setEnabled(false);
}

EditWebPluginGUI::~EditWebPluginGUI()
{
    delete ui;
}
///
/// \brief 初始化标题栏
///
void EditWebPluginGUI::initTitleBar()
{
    m_titleBar->move(0, 0);
    m_titleBar->raise();
    ///设置标题栏跑马灯效果，可以不设置;
    //m_titleBar->setTitleRoll();
    m_titleBar->setTitleIcon(":/Image/config.png");
    m_titleBar->setTitleContent(QStringLiteral("修改WEB插件信息"),10);
    m_titleBar->setButtonType(MIN_BUTTON);
    m_titleBar->setTitleWidth(this->width());
    ///这里需要设置成false，不允许通过标题栏拖动来移动窗口位置,否则会造成窗口位置错误;
    m_titleBar->setMoveParentWindowFlag(false);
    ///设置样式表
    loadStyleSheet(":/QSS/WidgetPanel.qss");
}
///
/// \brief 获取需要编辑的WEB插件信息
/// \param PluginStruct web插件信息
///
void EditWebPluginGUI::GetEditPluginInfo(WebPluginStruct PluginStruct)
{
    OriginalID=PluginStruct.id;
    ui->lineEdit_Id->setText(PluginStruct.id);
    ui->lineEdit_Name->setText(PluginStruct.name);
    ui->lineEdit_Url->setText(PluginStruct.url);
    ui->lineEdit_Des->setText(PluginStruct.describe);
    ui->lineEdit_Icon->setText(PluginStruct.icon_path);
    ui->lineEdit_Version->setText(PluginStruct.version);
}
///
/// \brief 确定按钮
///
void EditWebPluginGUI::on_pushButton_clicked()
{
    if(ui->lineEdit_Name->text().simplified()=="")
    {
        if(QMessageBox::warning(NULL,QStringLiteral("警告"),QStringLiteral("插件名称不能为空"),QMessageBox::Ok)==QMessageBox::Ok)
        {
            return;
        }
    }
    if(ui->lineEdit_Url->text().simplified()=="")
    {
        if(QMessageBox::warning(NULL,QStringLiteral("警告"),QStringLiteral("插件网址不能为空"),QMessageBox::Ok)==QMessageBox::Ok)
        {
            return;
        }
    }
    else
    {
        ///插件信息
        WebPluginStruct WebPluginInform;
        WebPluginInform.id=ui->lineEdit_Id->text().simplified();
        WebPluginInform.name=ui->lineEdit_Name->text().simplified();
        WebPluginInform.url=ui->lineEdit_Url->text().simplified();
        WebPluginInform.icon_path=ui->lineEdit_Icon->text().simplified();
        WebPluginInform.version=ui->lineEdit_Version->text().simplified();
        WebPluginInform.describe=ui->lineEdit_Des->text().simplified();
        bool res=WebPluginManageClass.EditPlugin(OriginalID,WebPluginInform);
        if(res)
        {
            if(QMessageBox::information(NULL,QStringLiteral("通知"),QStringLiteral("Web插件修改成功"),QMessageBox::Ok)==QMessageBox::Ok)
            {
                emit EditSuccessSignal();
                emit RefreshPluginBtn(OriginalID,ui->lineEdit_Id->text().simplified(),ui->lineEdit_Name->text().simplified(),ui->lineEdit_Icon->text().simplified(),ui->lineEdit_Url->text().simplified());
                this->close();
                return;
            }
        }
        else
        {
            if(QMessageBox::critical(NULL,QStringLiteral("错误"),QStringLiteral("Web插件修改失败"),QMessageBox::Ok)==QMessageBox::Ok)
            {
                return;
            }
        }
    }
}

void EditWebPluginGUI::on_pushButton_2_clicked()
{
    this->close();
}
///
/// \brief 鼠标移动事件
/// \param event
///
void EditWebPluginGUI::mouseMoveEvent(QMouseEvent *event)
{
    if (m_isPressed && m_MoveRange)
    {
        //移动窗体的位置
        QPoint movePoint = event->globalPos() - m_startMovePos;
        QPoint widgetPos = this->pos() + movePoint;
        m_startMovePos = event->globalPos();
        //窗体移动
        this->move(widgetPos.x(), widgetPos.y());
    }
    return QWidget::mouseMoveEvent(event);
}
///
/// \brief 鼠标释放事件
/// \param event
///
void EditWebPluginGUI::mouseReleaseEvent(QMouseEvent *event)
{
    m_isPressed = false;
    m_MoveRange=false;
    return QWidget::mouseReleaseEvent(event);
}
///
/// \brief 鼠标点击事件
/// \param event
///
void EditWebPluginGUI::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
    {
        m_isPressed = true;
        //开始移动的点位
        m_startMovePos = event->globalPos();
        if(event->y()<=33)
        {
            m_MoveRange=true;
        }
    }
    return QWidget::mousePressEvent(event);
}
///
/// \brief 选择图标
///
void EditWebPluginGUI::on_toolButton_clicked()
{
    QString Path = QFileDialog::getOpenFileName(this,QStringLiteral("选择插件图标"),"", tr("*.png;*.ico"));
    if(Path.length()>0)
    {
        ///获取应用程序
        ui->lineEdit_Icon->setText(Path);
    }
}
