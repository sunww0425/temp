﻿/*****************************************************
** 文件名：WebPluginManage.cpp
** 版 本：v.1.0
** 内容简述：Web插件管理类
** 创建日期： 2021.11.17
** 创建人：孙伟伟
** 修改记录：1.0
日期:2021.11.17  版本:v.1.0    修改人:孙伟伟   修改内容:创建
*****************************************************/
#include "webpluginmanage.h"
#include <QDomDocument>
#include <QApplication>
#include <QDebug>
#include <QFile>
#include "FunctionPage/pluginmanager.h"

WebPluginManage* WebPluginManage::mInstance = nullptr;
QMutex  WebPluginManage::mInsMutex;

WebPluginManage* WebPluginManage::instance()
{
    if(mInstance == nullptr)
    {

        QMutexLocker locker(&mInsMutex);
        if(mInstance == nullptr) mInstance = new WebPluginManage();
    }

    return mInstance;
}

WebPluginManage::WebPluginManage(QObject *parent) : QObject(parent)
{
    qRegisterMetaType<WebPluginStruct>("const WebPluginStruct&");
    qRegisterMetaType<QList<WebPluginStruct>>("const QList<WebPluginStruct>&");
    connect(PluginManager::instance(), SIGNAL(signalSendWebPluginList(QList<WebPluginStruct>)),
            this, SLOT(slotLoadPluginList(QList<WebPluginStruct>)));
}


void WebPluginManage::stop()
{
    setIsAboutExit(true);
    QStringList list = getAllLaunchers();
    foreach (QString id, list) {
        QString errorMsg;
        stopPlugin(id, errorMsg);
    }
}

void WebPluginManage::repairIconResourcePath()
{
    if(mPluginMap.size() == 0) return ;
    foreach (QString key, mPluginMap.keys())
    {
        WebPluginStruct& info = mPluginMap[key];
        if(info.adjustIconPath())
        {
            PluginManager::instance()->saveConfig(&info);
        }
    }
    return ;
}
///
/// \brief 读取插件信息
void WebPluginManage::slotLoadPluginList(const QList<WebPluginStruct>& list)
{
    PluginManager::instance()->writeLogInfo(QStringLiteral("Web插件管理器开始初始化.插件数:%1").arg(list.size()));
    mPluginMap.clear();
    foreach (WebPluginStruct info, list)
    {
        mPluginMap.insert(info.id, info);
    }
    //修正配置中的资源路径为相对路径
    repairIconResourcePath();
    //开始启动插件
    if(mPluginMap.count() > 0)
    {
        PluginManager::instance()->appendPluginID(mPluginMap.keys());
        //根据插件的状态,启用插件
        foreach (QString key, mPluginMap.keys())
        {
            WebPluginStruct info = mPluginMap.value(key);
            if(info.state == Plugin_State_Started)
            {
                QString errorMsg;
                startPlugin(info.id, errorMsg);
                PluginManager::instance()->writeLogInfo(QStringLiteral("Web插件%1(%2)的状态为启动,开始启用插件. %3")
                                                        .arg(info.id).arg(info.name).arg(errorMsg));
            }
        }
    }
    emit signalSendPluginList(mPluginMap.values());
    emit signalPluginInitFinished();
}

bool WebPluginManage::addPlugin(const WebPluginStruct &info, QString& errorMsg)
{
    bool isOk = false;
    if(1)
    {
        QMutexLocker locker(&mDataMutex);
        if(mPluginMap.contains(info.id))
        {
            errorMsg = QStringLiteral("当前插件id已存在");
            return false;
        }
        mPluginMap.insert(info.id, info);
        if(PluginManager::instance()->saveConfig(&(mPluginMap[info.id])))
        {
            isOk = true;
        } else
        {
            errorMsg = QStringLiteral("保存插件信息到配置文件失败");
            mPluginMap.remove(info.id);
        }
    }
    if(isOk)
    {
        PluginManager::instance()->appendPluginID(info.id);
        emit signalEditPluginSuccess(info);
    }
    return isOk;
}

bool WebPluginManage::modifyPlugin(const WebPluginStruct &info, QString &errorMsg)
{
    bool isOk = false;
    if(1)
    {
        QMutexLocker locker(&mDataMutex);
        if(!mPluginMap.contains(info.id))
        {
            errorMsg = QStringLiteral("当前插件id不存在");
            return false;
        }
        WebPluginStruct old_info = mPluginMap.value(info.id);
        mPluginMap.insert(info.id, info);
         if(PluginManager::instance()->saveConfig(&(mPluginMap[info.id])))
        {
            isOk = true;
        } else
        {
            mPluginMap.insert(info.id, old_info);
            errorMsg = QStringLiteral("保存插件信息到配置文件失败");
        }
    }
    if(isOk)  emit signalEditPluginSuccess(info);
    return isOk;
}

bool WebPluginManage::deletePlugin(const QString &id, QString& errorMsg)
{
    bool isOk = false;
    if(1)
    {
        QMutexLocker locker(&mDataMutex);
        if(!mPluginMap.contains(id))
        {
            errorMsg = QStringLiteral("当前插件id不存在");
            return false;
        }
        WebPluginStruct info = mPluginMap.take(id);
        if(PluginManager::instance()->deletePlugin(&info))
        {
            isOk = true;
        } else
        {
            mPluginMap.insert(id, info);
            errorMsg = QStringLiteral("保存插件信息到配置文件失败");
        }
    }
    if(isOk)
    {
        PluginManager::instance()->removePluginID(id);
        emit signalStopPlugin(id);
        emit signalDelPluginSuccess(id);
    }
    return isOk;
}

bool WebPluginManage::updatePluginState(const QString &id, PluginState state, QString& errorMsg)
{
    bool isOk = false;
    if(1)
    {
        QMutexLocker locker(&mDataMutex);
        if(!mPluginMap.contains(id))
        {
            errorMsg = QStringLiteral("当前插件id不存在");
            return false;
        }
        WebPluginStruct old_info = mPluginMap[id];
        if(old_info.state == state) return true;

        mPluginMap[id].state = state;
        if(PluginManager::instance()->saveConfig(&(mPluginMap[id])))
        {
            isOk = true;
        } else
        {
            mPluginMap.insert(id, old_info);
            errorMsg = QStringLiteral("保存插件信息到配置文件失败");
        }
    }
    if(isOk)
    {
        if(!mIsAboutExit)emit signalEditPluginSuccess(mPluginMap[id]);
        if(state == Plugin_State_Started)
        {
            WebPluginStruct& info = mPluginMap[id];
            if(mLoadMode == Plugin_Load_Orinal)
            {
                emit signalStartPlugin(info);
            } else
            {
                return startPluginWithLauncher(info);
            }
        } else
        {
            emit signalStopPlugin(id);
        }
    }
    return isOk;
}

bool WebPluginManage::getPluginWithId(const QString &id, WebPluginStruct &info)
{
    QMutexLocker locker(&mDataMutex);
    qDebug()<<"current web plugins:"<<mPluginMap.keys()<<"target id:"<<id;
    if(!mPluginMap.contains(id)) return false;
    info = mPluginMap.value(id);
    return true;
}

bool WebPluginManage::startPlugin(const QString& id,  QString& errorMsg)
{
    WebPluginStruct info;
    if(!getPluginWithId(id, info))
    {
        errorMsg = QStringLiteral("当前id[%1]对应的插件不存在").arg(id);
        return false;
    }
    PluginManager::instance()->writeLogInfo(QStringLiteral("开始启动插件.id:%1, 名称:%2, url:%3").arg(info.id).arg(info.name).arg(info.url));

    if(info.state == Plugin_State_Started)
    {
        if(mLoadMode == Plugin_Load_Orinal)
        {
            emit signalStartPlugin(info);
            return errorMsg.size() == 0;
        } else
        {
            return startPluginWithLauncher(info);
        }
    } else
    {
        return updatePluginState(info.id, Plugin_State_Started, errorMsg);
    }

    return true;
}

bool WebPluginManage::startPluginWithLauncher(const WebPluginStruct &plugin)
{
    if(getLauncherOfId(plugin.id)) return true;
    PluginManager::instance()->writeLogInfo(QStringLiteral("Web插件管理器启动插件%1(%2) %3").arg(plugin.id).arg(plugin.name).arg(plugin.url));
    AppLaunchParam param;
    param.mId = plugin.id;
    param.mName = plugin.name;
    param.mUrl = plugin.url;
    param.mType = plugin.type;
    param.mTarget = plugin.id;
    AppLauncher* launcher = new AppLauncher(param, this);
    connect(launcher, SIGNAL(signalSendWindId(QString,qint64)), this, SLOT(slotRecvPluginWId(QString,qint64)));
    connect(launcher, SIGNAL(signalPluginEnd(QString)), this,  SLOT(slotRecvPluginLauncherEnd(QString)));
    launcher->start();
    appendLauncher(plugin.id, launcher);
    return true;
}


bool WebPluginManage::stopPlugin(const QString& id, QString& errorMsg)
{
    PluginManager::instance()->writeLogInfo(QStringLiteral("开始停止插件[%1]").arg(id));
    WebPluginStruct info;
    if(!getPluginWithId(id, info))
    {
        errorMsg = QStringLiteral("当前id[%1]对应的插件不存在").arg(id);
        PluginManager::instance()->writeLogInfo(QStringLiteral("停止插件[%1]失败.%2").arg(id).arg(errorMsg));
        return false;
    }
    if(info.state == Plugin_State_Stopped)
    {
        errorMsg = QStringLiteral("当前id[%1]对应的插件已经被禁用").arg(id);
        PluginManager::instance()->writeLogInfo(QStringLiteral("停止插件[%1]失败.%2").arg(id).arg(errorMsg));
        return false;
    }
    //设定插件的状态
    AppLauncher* launcher = getLauncherOfId(id);
    if(launcher)
    {
        delete launcher;
        launcher = nullptr;
    }
    removeLanuncher(id);
    if(!mIsAboutExit)
    {
        if(updatePluginState(id, Plugin_State_Stopped, errorMsg))
        {
            PluginManager::instance()->writeLogInfo(QStringLiteral("停止插件[%1]成功").arg(id));
            return true;
        }

        PluginManager::instance()->writeLogInfo(QStringLiteral("停止插件[%1]失败.%2").arg(id).arg(errorMsg));
        return false;
    }
    return true;
}

bool WebPluginManage::isPluginIdExist(const QString &id)
{
    return PluginManager::instance()->isIdExist(id);
}

void WebPluginManage::appendLauncher(const QString &id, AppLauncher *launcher)
{
    QMutexLocker locker(&mLauncherMutex);
    mPluginLauncherMap.insert(id, launcher);
}

void WebPluginManage::removeLanuncher(const QString &id)
{
    QMutexLocker locker(&mLauncherMutex);
    mPluginLauncherMap.remove(id);
}

AppLauncher* WebPluginManage::getLauncherOfId(const QString &id)
{
    QMutexLocker locker(&mLauncherMutex);
    return mPluginLauncherMap.value(id, nullptr);
}

QStringList WebPluginManage::getAllLaunchers()
{
    QMutexLocker locker(&mLauncherMutex);
    return mPluginLauncherMap.keys();
}

//接收到插件启动器返回的插件窗口id
void WebPluginManage::slotRecvPluginWId(const QString &pluginId, qint64 wid)
{
    WebPluginStruct plugin = mPluginMap.value(pluginId);
    PluginManager::instance()->writeLogInfo(QStringLiteral("Web插件管理器收到插件启动器返回的窗口信息. 插件:%1(%2), 窗口:%3")
                          .arg(plugin.id).arg(plugin.name).arg(wid));

    //通知主界面显示当前插件的窗口
    emit signalStartPlugin(plugin, wid);
}

//接收到插件程序结束的情况
void WebPluginManage::slotRecvPluginLauncherEnd(const QString &id)
{
    PluginManager::instance()->writeLogInfo(QStringLiteral("Qt插件管理器收到插件启动器返回插件%1结束信息").arg(id));
    if(!mIsAboutExit)
    {
        PluginManager::instance()->writeLogInfo(QStringLiteral("更新插件%1状态为结束").arg(id));
        QString errorMsg;
        updatePluginState(id, Plugin_State_Stopped, errorMsg);
    }
}

void WebPluginManage::reloadPluginWindow(const QString &id)
{
    PluginManager::instance()->writeLogInfo(QStringLiteral("Qt插件管理器重新获取插件%1窗口").arg(id));
    AppLauncher* launcher = getLauncherOfId(id);
    if(!launcher) return;
    launcher->findWindow();
}

