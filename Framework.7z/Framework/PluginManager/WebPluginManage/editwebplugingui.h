﻿/*****************************************************
** 文件名：EditWebPluginGUI.h
** 版 本：v.1.0
** 内容简述：编辑Web插件界面
** 创建日期： 2021.11.17
** 创建人：孙伟伟
** 修改记录：1.0
日期:2021.11.17  版本:v.1.0    修改人:孙伟伟   修改内容:创建
*****************************************************/
#ifndef EDITWEBPLUGINGUI_H
#define EDITWEBPLUGINGUI_H

#include <QWidget>
#include "WebPluginManage/WebPluginInfo.h"
#include "WebPluginManage/webpluginmanage.h"
#include "BaseWindow/basewindow.h"

namespace Ui {
class EditWebPluginGUI;
}

class EditWebPluginGUI : public BaseWindow
{
    Q_OBJECT

public:
    explicit EditWebPluginGUI(QWidget *parent = nullptr);
    ~EditWebPluginGUI();
    ///
    /// \brief 获取需要编辑的WEB插件信息
    /// \param PluginStruct web插件信息
    ///
    void GetEditPluginInfo(WebPluginStruct PluginStruct);
signals:
    ///
    /// \brief 信息修改成功通知
    ///
    void EditSuccessSignal();
    ///
    /// \brief 刷新改变的插件按钮
    /// \param ID 插件ID
    /// \param Name 插件名称
    /// \param IconPath 插件图标
    ///
    void RefreshPluginBtn(QString OriginalID,QString ID,QString Name,QString IconPath, QString Url);
protected:
    ///
    /// \brief 鼠标移动事件
    /// \param event
    ///
    void mouseMoveEvent(QMouseEvent *event) override;
    ///
    /// \brief 鼠标释放事件
    /// \param event
    ///
    void mouseReleaseEvent(QMouseEvent *event) override;
    ///
    /// \brief 鼠标点击事件
    /// \param event
    ///
    void mousePressEvent(QMouseEvent *event) override;

private slots:
    ///
    /// \brief 初始化标题栏
    ///
    void initTitleBar();
    ///
    /// \brief 确定按钮
    ///
    void on_pushButton_clicked();
    ///
    /// \brief 关闭按钮
    ///
    void on_pushButton_2_clicked();
    ///
    /// \brief 选择图标
    ///
    void on_toolButton_clicked();

private:
    Ui::EditWebPluginGUI *ui;
    ///鼠标是否点击
    bool m_isPressed;
    ///是否在拖动范围
    bool m_MoveRange=false;
    ///开始移动的点位
    QPoint m_startMovePos;
    ///记录初始编号
    QString OriginalID;
};

#endif // EDITWEBPLUGINGUI_H
