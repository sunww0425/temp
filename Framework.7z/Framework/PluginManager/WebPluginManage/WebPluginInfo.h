﻿/*****************************************************
** 文件名：WebPluginStruct.h
** 版 本：v.1.0
** 内容简述：Web插件界面信息结构体
** 创建日期： 2021.11.17
** 创建人：孙伟伟
** 修改记录：1.0
日期:2021.11.17  版本:v.1.0    修改人:孙伟伟   修改内容:创建
*****************************************************/
#ifndef WEBPLUGININFO_H
#define WEBPLUGININFO_H

#include <QString>
#include <QObject>
#include "FunctionPage/OpenPluginInfo.h"

struct WebPluginStruct : public OpenPluginStruct
{
    WebPluginStruct() : OpenPluginStruct()
    {
        type = PLugin_Type_Web;
    }

    WebPluginStruct(const QDomElement& e) : OpenPluginStruct(e)
    {
        type = PLugin_Type_Web;
    }

public:
};

Q_DECLARE_METATYPE(WebPluginStruct)

#endif // WEBPLUGININFO_H
