﻿/*****************************************************
** 文件名：WebPluginManageGUI.cpp
** 版 本：v.1.0
** 内容简述：Web插件管理界面
** 创建日期： 2026.02.09
** 创建人：孙伟伟
** 修改记录：1.0
日期:2026.02.09  版本:v.1.0    修改人:孙伟伟   修改内容:创建
*****************************************************/
#include "webpluginmanagegui.h"
#include "ui_webpluginmanagegui.h"
#include <QDebug>
#include <QMessageBox>
#include <QFile>

WebPluginManageGUI::WebPluginManageGUI(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::WebPluginManageGUI)
{
    ui->setupUi(this);
    ui->Btn_Refresh->setVisible(false);

    //已选择接收机列表设置交替行变色
    ui->tableWidget->setAlternatingRowColors(true);

    //设置垂直表头
    ui->tableWidget->verticalHeader()->setVisible(false);
    ui->tableWidget->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->tableWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidget->setSelectionMode(QAbstractItemView::SingleSelection);
}

WebPluginManageGUI::~WebPluginManageGUI()
{
    delete ui;
}

void WebPluginManageGUI::setTitle(const QString &title)
{
   ui->title->setText(title);
}

///
/// \brief 双击行信息
/// \param item 鼠标双击的表格行信息
///
void WebPluginManageGUI::on_tableWidget_itemDoubleClicked(QTableWidgetItem *item)
{

}

///
/// \brief 点击刷新
///
void WebPluginManageGUI::on_Btn_Refresh_clicked()
{

}
///
/// \brief 点击添加
///
void WebPluginManageGUI::on_Btn_Creat_clicked()
{


}
///
/// \brief 删除
///
void WebPluginManageGUI::on_Btn_Delete_clicked()
{

}
///
/// \brief 修改
///
void WebPluginManageGUI::on_Btn_Edit_clicked()
{

}
///
/// \brief 点击禁用
///
void WebPluginManageGUI::on_Btn_Disable_clicked()
{

}

///
/// \brief 点击启用
///
void WebPluginManageGUI::on_Btn_Enable_clicked()
{

}

