﻿/*****************************************************
** 文件名：AddWebPluginGUI.cpp
** 版 本：v.1.0
** 内容简述：添加Web插件界面
** 创建日期： 2021.11.17
** 创建人：孙伟伟
** 修改记录：1.0
日期:2021.11.17  版本:v.1.0    修改人:孙伟伟   修改内容:创建
*****************************************************/
#include "addwebplugingui.h"
#include "ui_addwebplugingui.h"
#include <QFileInfo>
#include <QMouseEvent>
#include <QFileDialog>
#include "FunctionPage/OpenPluginInfo.h"
#include "pluginutils.h"
#include <QUuid>

AddWebPluginGUI::AddWebPluginGUI(QWidget *parent) :
    BaseWindow(parent),
    ui(new Ui::AddWebPluginGUI)
{
    ui->setupUi(this);
    setAttribute(Qt::WA_DeleteOnClose);
    ///初始化标题栏
    initTitleBar();
    connect(ui->lineEdit_Icon, SIGNAL(textChanged(QString)), this, SLOT(slotIconTextedChanged(QString)));
    ui->lineEdit_Id->setEnabled(false);
    ui->icon_btn->setIconSize(QSize(16,16));
}

AddWebPluginGUI::~AddWebPluginGUI()
{
    delete ui;
}
///
/// \brief 初始化标题栏
///
void AddWebPluginGUI::initTitleBar()
{
    m_titleBar->move(0, 0);
    m_titleBar->raise();
    ///设置标题栏跑马灯效果，可以不设置;
    //m_titleBar->setTitleRoll();
    m_titleBar->setTitleIcon(":/Image/saving.png");
    m_titleBar->setTitleContent(QStringLiteral("添加WEB插件"),10);
    m_titleBar->setButtonType(MIN_BUTTON);
    m_titleBar->setTitleWidth(this->width());
    ///这里需要设置成false，不允许通过标题栏拖动来移动窗口位置,否则会造成窗口位置错误;
    m_titleBar->setMoveParentWindowFlag(false);
    ///设置样式表
    loadStyleSheet(":/QSS/WidgetPanel.qss");
}

void AddWebPluginGUI::setEditInfo(const WebPluginStruct &info)
{
    mData = info;
    if(mData.id.size() == 0)
    {
        mData.id = QString("Web-%1").arg(QUuid::createUuid().toString(QUuid::WithoutBraces));
        ui->lineEdit_Id->setEnabled(true);
        mData.icon_path = "Images/WebPlugin.png";
        mIsNew = true;
    } else
    {
        mIsNew = false;
        ui->lineEdit_Id->setEnabled(false);
    }
    ui->lineEdit_Des->setText(mData.describe);
    ui->lineEdit_Icon->setText(mData.icon_path);
    ui->lineEdit_Id->setText(mData.id);
    ui->lineEdit_Name->setText(mData.name);
    ui->lineEdit_Url->setText(mData.url);
    ui->lineEdit_Version->setText(mData.version);
    if(ui->lineEdit_Icon->text().size() == 0)
    {
        slotIconTextedChanged(ui->lineEdit_Icon->text());
    }
}

void AddWebPluginGUI::slotIconTextedChanged(const QString &text)
{
    if(text.size() > 0)
    {
        if(text.startsWith("Images"))
        {
            ui->icon_btn->setIcon(QIcon(PluginUtils::getFullIconPath(text)));
        } else
        {
            ui->icon_btn->setIcon(QIcon(text));
        }
    } else
    {
        ui->lineEdit_Icon->setText("Images/WebPlugin.png");
    }
}

///
/// \brief 取消按钮
///
void AddWebPluginGUI::on_cancel_btn_clicked()
{
    ClearForm();
    this->close();
}
///
/// \brief 添加
///
void AddWebPluginGUI::on_ok_btn_clicked()
{
    if(ui->lineEdit_Id->text().simplified()=="")
    {
        PluginUtils::warningMsgBox(QStringLiteral("唯一标识不能为空"));
        return;
    }
    if(ui->lineEdit_Name->text().simplified()=="")
    {
        PluginUtils::warningMsgBox(QStringLiteral("插件名称不能为空"));
        return;
    }
    if(ui->lineEdit_Url->text().simplified()=="")
    {
        PluginUtils::warningMsgBox(QStringLiteral("插件网址不能为空"));
        return;
    }

    mData.id=ui->lineEdit_Id->text().simplified();
    mData.name=ui->lineEdit_Name->text().simplified();
    mData.url=ui->lineEdit_Url->text().simplified();
    mData.icon_path=ui->lineEdit_Icon->text().simplified();
    mData.version=ui->lineEdit_Version->text().simplified();
    mData.describe=ui->lineEdit_Des->text().simplified();

    QString errorMsg;
    if((mIsNew && WebPluginManage::instance()->addPlugin(mData, errorMsg))
            || WebPluginManage::instance()->modifyPlugin(mData, errorMsg))
    {
        PluginUtils::informationMsgBox(QStringLiteral("WEB插件编辑成功"));
        close();
    }
    else
    {
        PluginUtils::warningMsgBox(QStringLiteral("WEB插件编辑失败"));
        return;
    }
}
///
/// \brief 清空窗体
///
void AddWebPluginGUI::ClearForm()
{
    ui->lineEdit_Id->setText("");
    ui->lineEdit_Name->setText("");
    ui->lineEdit_Url->setText("");
    ui->lineEdit_Des->setText("");
    ui->lineEdit_Icon->setText("");
    ui->lineEdit_Version->setText("");
}
///
/// \brief 鼠标移动事件
/// \param event
///
void AddWebPluginGUI::mouseMoveEvent(QMouseEvent *event)
{
    if (m_isPressed && m_MoveRange)
    {
        //移动窗体的位置
        QPoint movePoint = event->globalPos() - m_startMovePos;
        QPoint widgetPos = this->pos() + movePoint;
        m_startMovePos = event->globalPos();
        //窗体移动
        this->move(widgetPos.x(), widgetPos.y());
    }
    return QWidget::mouseMoveEvent(event);
}
///
/// \brief 鼠标释放事件
/// \param event
///
void AddWebPluginGUI::mouseReleaseEvent(QMouseEvent *event)
{
    m_isPressed = false;
    m_MoveRange=false;
    return QWidget::mouseReleaseEvent(event);
}
///
/// \brief 鼠标点击事件
/// \param event
///
void AddWebPluginGUI::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
    {
        m_isPressed = true;
        //开始移动的点位
        m_startMovePos = event->globalPos();
        if(event->y()<=33)
        {
            m_MoveRange=true;
        }
    }
    return QWidget::mousePressEvent(event);
}
///
/// \brief 选择图标
///
void AddWebPluginGUI::on_icon_btn_clicked()
{
    QString path = QFileDialog::getOpenFileName(this,QStringLiteral("选择插件图标"),"", tr("*.png;*.ico"));
    if(path.length()>0)
    {
        //检查是否是在Images目录下选择的图标,如果是,就显示相对路径
        if(path.startsWith(QApplication::applicationDirPath() + "/Images"))
        {
            path = path.replace(QApplication::applicationDirPath() + "/", "");
        }
        ///获取应用程序
        ui->lineEdit_Icon->setText(path);
    }
}
