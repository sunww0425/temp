﻿/*****************************************************
** 文件名：WebPluginManageGUI.h
** 版 本：v.1.0
** 内容简述：Web插件管理界面
** 创建日期： 2026.02.09
** 创建人：孙伟伟
** 修改记录：1.0
日期:2026.02.09  版本:v.1.0    修改人:孙伟伟   修改内容:创建
*****************************************************/
#ifndef WEBPLUGINMANAGEGUI_H
#define WEBPLUGINMANAGEGUI_H

#include <QWidget>
#include <QTableWidgetItem>

namespace Ui {
class WebPluginManageGUI;
}

class WebPluginManageGUI : public QWidget
{
    Q_OBJECT

public:
    explicit WebPluginManageGUI(QWidget *parent = nullptr);
    ~WebPluginManageGUI();

    void setTitle(const QString& title);

private slots:

private:

signals:


private slots:
    ///
    /// \brief 双击行信息
    /// \param item 鼠标双击的表格行信息
    ///
    void on_tableWidget_itemDoubleClicked(QTableWidgetItem *item);
    ///
    /// \brief 点击刷新
    ///
    void on_Btn_Refresh_clicked();
    ///
    /// \brief 点击添加
    ///
    void on_Btn_Creat_clicked();
    ///
    /// \brief 删除
    ///
    void on_Btn_Delete_clicked();
    ///
    /// \brief 编辑按钮
    ///
    void on_Btn_Edit_clicked();
    ///
    /// \brief 点击禁用
    ///
    void on_Btn_Disable_clicked();
    ///
    /// \brief 点击启用
    ///
    void on_Btn_Enable_clicked();

private:
    Ui::WebPluginManageGUI *ui;
};

#endif // WEBPLUGINMANAGEGUI_H
