﻿#include "editqtplugingui.h"
#include "ui_editqtplugingui.h"
#include "BaseWindow/basewindow.h"
#include <QMouseEvent>
#include <QFileDialog>
#include <QMessageBox>
#include "qtpluginmanage.h"
#include "pluginutils.h"

EditQtPluginGUI::EditQtPluginGUI(bool new_plugin, QWidget *parent) :
    BaseWindow(parent),
    ui(new Ui::EditQtPluginGUI),
    mNewPlugin(new_plugin)
{
    ui->setupUi(this);
    setAttribute(Qt::WA_DeleteOnClose);
    ///初始化标题栏
    initTitleBar();
    connect(ui->lineEdit_Icon, SIGNAL(textChanged(QString)), this, SLOT(slotIconTextedChanged(QString)));
    ui->lineEdit_Id->setEnabled(false);
    ui->lineEdit_Des->setEnabled(true);
    ui->lineEdit_Icon->setEnabled(true);
    ui->lineEdit_Name->setEnabled(true);
    ui->lineEdit_Url->setEnabled(false);
    ui->lineEdit_Version->setEnabled(true);
    ui->icon_btn->setIconSize(QSize(16,16));
}

EditQtPluginGUI::~EditQtPluginGUI()
{
    delete ui;
}
///
/// \brief 获取需要编辑的qt插件信息
/// \param PluginStruct qt插件信息
///
void EditQtPluginGUI::setEditPluginInfo(const QTPluginStruct &info)
{
    mData = info;
    ui->lineEdit_Id->setText(info.id);
    ui->lineEdit_Name->setText(info.name);
    ui->lineEdit_Url->setText(info.url);
    ui->lineEdit_Des->setText(info.describe);
    ui->lineEdit_Icon->setText(info.icon_path);
    ui->lineEdit_Version->setText(info.version);
    if(ui->lineEdit_Icon->text().size() == 0)
    {
        slotIconTextedChanged(ui->lineEdit_Icon->text());
    }
}

void EditQtPluginGUI::slotIconTextedChanged(const QString &text)
{
    if(text.size() > 0)
    {
        if(text.startsWith("Images"))
        {
            ui->icon_btn->setIcon(QIcon(PluginUtils::getFullIconPath(text)));
        } else
        {
            ui->icon_btn->setIcon(QIcon(text));
        }
    } else
    {
        ui->lineEdit_Icon->setText("Images/QTPlugin.png");
    }
}

///
/// \brief 初始化标题栏
///
void EditQtPluginGUI::initTitleBar()
{
    m_titleBar->move(0, 0);
    m_titleBar->raise();
    ///设置标题栏跑马灯效果，可以不设置;
    //m_titleBar->setTitleRoll();
    m_titleBar->setTitleIcon(":/Image/config.png");
    m_titleBar->setTitleContent(QStringLiteral("修改QT插件信息"),10);
    m_titleBar->setButtonType(MIN_BUTTON);
    m_titleBar->setTitleWidth(this->width());
    ///这里需要设置成false，不允许通过标题栏拖动来移动窗口位置,否则会造成窗口位置错误;
    m_titleBar->setMoveParentWindowFlag(false);
    ///设置样式表
    loadStyleSheet(":/QSS/WidgetPanel.qss");
}

///
/// \brief 鼠标移动事件
/// \param event
///
void EditQtPluginGUI::mouseMoveEvent(QMouseEvent *event)
{
    if (m_isPressed && m_MoveRange)
    {
        //移动窗体的位置
        QPoint movePoint = event->globalPos() - m_startMovePos;
        QPoint widgetPos = this->pos() + movePoint;
        m_startMovePos = event->globalPos();
        //窗体移动
        this->move(widgetPos.x(), widgetPos.y());
    }
    return QWidget::mouseMoveEvent(event);
}
///
/// \brief 鼠标释放事件
/// \param event
///
void EditQtPluginGUI::mouseReleaseEvent(QMouseEvent *event)
{
    m_isPressed = false;
    m_MoveRange=false;
    return QWidget::mouseReleaseEvent(event);
}
///
/// \brief 鼠标点击事件
/// \param event
///
void EditQtPluginGUI::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
    {
        m_isPressed = true;
        //开始移动的点位
        m_startMovePos = event->globalPos();
        if(event->y()<=33)
        {
            m_MoveRange=true;
        }
    }
    return QWidget::mousePressEvent(event);
}

void EditQtPluginGUI::on_cancel_btn_clicked()
{
    this->close();
}
///
/// \brief 选择图标
///
void EditQtPluginGUI::on_icon_btn_clicked()
{
    QString path = QFileDialog::getOpenFileName(this,QStringLiteral("选择插件图标"),"", tr("*.png;*.ico"));
    if(path.length()>0)
    {
        //检查是否是在Images目录下选择的图标,如果是,就显示相对路径
        if(path.startsWith(QApplication::applicationDirPath() + "/Images"))
        {
            path = path.replace(QApplication::applicationDirPath() + "/", "");
        }
        ///获取应用程序
        ui->lineEdit_Icon->setText(path);
    }
}
///
/// \brief 点击确定按钮
///
void EditQtPluginGUI::on_ok_btn_clicked()
{
    if(ui->lineEdit_Id->text().simplified().size() == 0)
    {
        PluginUtils::warningMsgBox(QStringLiteral("插件id不能为空"));
        return;
    }
    if(ui->lineEdit_Name->text().simplified().size() == 0)
    {
        PluginUtils::warningMsgBox(QStringLiteral("插件名称不能为空"));
        return;
    }
    if(ui->lineEdit_Url->text().simplified().size() == 0)
    {
        PluginUtils::warningMsgBox(QStringLiteral("插件路径不能为空"));
        return;
    }


    QString errorMsg;
    //检查插件的id是否发生了变化
    bool new_plugin = false;
    if(mData.id != ui->lineEdit_Id->text().simplified())
    {
        if(PluginUtils::warningMsgBoxWithOption(QStringLiteral("插件id发生了变化,继续保存将要删除原来的插件信息?")) == Msg_Cancel)
        {
            return;
        }
        if(!QTPluginManage::instance()->deletePlugin(mData.id, errorMsg))
        {
            PluginUtils::warningMsgBox(errorMsg);
            return;
        }
        new_plugin = true;
    }

    ///插件信息
    mData.id=ui->lineEdit_Id->text().simplified();
    mData.name=ui->lineEdit_Name->text().simplified();
    mData.icon_path=ui->lineEdit_Icon->text().simplified();
    mData.url=ui->lineEdit_Url->text().simplified();
    mData.version=ui->lineEdit_Version->text().simplified();
    mData.describe=ui->lineEdit_Des->text().simplified();
    if((mNewPlugin && QTPluginManage::instance()->addPlugin(mData, errorMsg))
            || QTPluginManage::instance()->modifyPlugin(mData, errorMsg))
    {
        if(!mNewPlugin) PluginUtils::informationMsgBox(QStringLiteral("QT插件修改成功"));
        close();
    }
    else
    {
        PluginUtils::warningMsgBox(QStringLiteral("QT插件修改失败"));
        return;
    }
}
