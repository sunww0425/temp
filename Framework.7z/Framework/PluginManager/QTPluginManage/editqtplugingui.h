﻿#ifndef EDITQTPLUGINGUI_H
#define EDITQTPLUGINGUI_H

#include <QWidget>
#include "BaseWindow/basewindow.h"
#include "QTPluginManage/qtpluginmanage.h"
#include "QTPluginManage/QTPluginInfo.h"

namespace Ui {
class EditQtPluginGUI;
}

class EditQtPluginGUI : public BaseWindow
{
    Q_OBJECT

public:
    explicit EditQtPluginGUI(bool new_plugin, QWidget *parent = nullptr);
    ~EditQtPluginGUI();
    ///
    /// \brief 获取需要编辑的qt插件信息
    /// \param PluginStruct qt插件信息
    ///
    void setEditPluginInfo(const QTPluginStruct& PluginStruct);
signals:
    ///
    /// \brief 信息修改成功通知
    ///
    void EditSuccessSignal();
    ///
    /// \brief 刷新改变的插件按钮
    /// \param OriginalID 插件原ID
    /// \param ID 插件ID
    /// \param Name 插件名称
    /// \param IconPath 插件图标
    ///
    void RefreshPluginBtn(QString OriginalID,QString ID,QString Name,QString IconPath, QString Url);

private slots:
    ///
    /// \brief 初始化标题栏
    ///
    void initTitleBar();
    ///
    /// \brief 取消按钮
    ///
    void on_cancel_btn_clicked();
    ///
    /// \brief 选择图标
    ///
    void on_icon_btn_clicked();
    ///
    /// \brief 点击确定按钮
    ///
    void on_ok_btn_clicked();
    //图标修改
    void slotIconTextedChanged(const QString& text);

protected:
    ///
    /// \brief 鼠标移动事件
    /// \param event
    ///
    void mouseMoveEvent(QMouseEvent *event) override;
    ///
    /// \brief 鼠标释放事件
    /// \param event
    ///
    void mouseReleaseEvent(QMouseEvent *event) override;
    ///
    /// \brief 鼠标点击事件
    /// \param event
    ///
    void mousePressEvent(QMouseEvent *event) override;

private:
    Ui::EditQtPluginGUI *ui;
    ///鼠标是否点击
    bool m_isPressed;
    ///是否在拖动范围
    bool m_MoveRange=false;
    ///开始移动的点位
    QPoint m_startMovePos;
    //原始数据
    QTPluginStruct          mData;
    //
    bool                           mNewPlugin;
};

#endif // EDITQTPLUGINGUI_H
