﻿/*****************************************************
** 文件名：QTPluginManageGUI.cpp
** 版 本：v.1.0
** 内容简述：QT插件管理界面
** 创建日期： 2026.02.09
** 创建人：孙伟伟
** 修改记录：1.0
日期:2026.02.09  版本:v.1.0    修改人:孙伟伟   修改内容:创建
*****************************************************/
#include "qtpluginmanagegui.h"
#include "ui_qtpluginmanagegui.h"
#include <QFile>
#include <QFileDialog>
#include <QDebug>
#include <QLibrary>
#include <QJsonObject>
#include <QJsonDocument>
#include <QMessageBox>
#include <QProcess>

QTPluginManageGUI::QTPluginManageGUI(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::QTPluginManageGUI)

{
    ui->setupUi(this);
    ///设置交替行变色
    ui->tableWidget->setAlternatingRowColors(true);
    ///设置垂直表头
    ui->tableWidget->verticalHeader()->setVisible(false);
    ui->tableWidget->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->tableWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
}

QTPluginManageGUI::~QTPluginManageGUI()
{
    delete ui;
}

///
/// \brief 设置标题
/// \param title 内容
///
void QTPluginManageGUI::setTitle(const QString &title)
{
    ui->title->setText(title);
}

///
/// \brief 加载插件
///
void QTPluginManageGUI::on_Btn_Creat_clicked()
{

}

///
/// \brief 卸载
///
void QTPluginManageGUI::on_Btn_Delete_clicked()
{

}

///
/// \brief 点击编辑按钮
///
void QTPluginManageGUI::on_Btn_Edit_clicked()
{

}

///
/// \brief 点击启用按钮
///
void QTPluginManageGUI::on_Btn_Able_clicked()
{

}
///
/// \brief 点击禁用按钮
///
void QTPluginManageGUI::on_Btn_Unable_clicked()
{

}

