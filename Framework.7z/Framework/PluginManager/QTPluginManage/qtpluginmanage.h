﻿/*****************************************************
** 文件名：QTPluginManage.h
** 版 本：v.1.0
** 内容简述：QT插件管理类
** 创建日期： 2025.02.09
** 创建人：孙伟伟
** 修改记录：1.0
日期:2025.02.09  版本:v.1.0    修改人:孙伟伟   修改内容:创建
*****************************************************/
#ifndef QTPLUGINMANAGE_H
#define QTPLUGINMANAGE_H

#include <QObject>
#include <QMap>
#include <QLibrary>
#include <QJsonObject>
#include <QJsonDocument>
#include <QMutex>


class AppPluginInterfaceExport;
class QTPluginManage : public QObject
{
    Q_OBJECT
public:
    static QTPluginManage* instance();
protected:
    explicit QTPluginManage(QObject *parent = nullptr);
public:
    void setLoadMode(int mode) {mLoadMode = (PluginLoadMode)mode;}
    int getLoadMode() const {return mLoadMode;}
     void stop();
    void setIsAboutClose(bool sts) {mIsAboutExit = sts;}
    bool addPlugin(const QTPluginStruct& info, QString& errorMsg);
    bool modifyPlugin(const QTPluginStruct& info, QString& errorMsg);
    bool deletePlugin(const QString& id, QString& errorMsg);
    bool updatePluginState(const QString& id, PluginState state, QString& errorMsg);
    QList<QTPluginStruct> getPluginList() {return mPluginMap.values();}
    bool startPlugin(const QString& id, QString& errorMsg);
    bool stopPlugin(const QString& id, QString& errorMsg);
    bool getPluginWithId(const QString& id, QTPluginStruct& info);
    bool loadPlugin(const QString &path, QTPluginStruct& info, QString& errorMsg);
    bool unloadPlugin(const QString &path);
    bool isPluginIdExist(const QString& id);

    void reloadPluginWindow(const QString& id);
private:
    void appendLauncher(const QString& id, AppLauncher* launcher);
    void removeLanuncher(const QString& id);
    AppLauncher* getLauncherOfId(const QString& id);
    QStringList getAllLaunchers();

signals:
    //发送到插件编辑管理界面的信号
    void signalEditPluginSuccess(const QTPluginStruct& info);
    void signalDelPluginSuccess(const QString& id);
    void signalSendPluginList(const QList<QTPluginStruct>& list);
    //发送到插件主界面的信号
    void signalPluginInitFinished();
    void signalStartPlugin(const QTPluginStruct& plugin, qint64 wid = 0);
    void signalStopPlugin(const QString& id);
    void signalStartPluginList(const QList<QTPluginStruct> &list);
    //插件自身日志
    void signalSendLogMsg(QtMsgType type, const QString& id, const QString& msg);

public slots:
    void slotLoadPluginList(const QList<QTPluginStruct>& list);
    void slotRecvPluginLauncherEnd(const QString &id);
    void slotRecvPluginWId(const QString& pluginId, qint64 wid);
private:
    //修复配置文件存在的资源使用
    void repairIconResourcePath();
    bool startPluginWithLauncher(const QTPluginStruct& plugin);

protected:
private:
    static QTPluginManage*              mInstance;
    static QMutex                               mInsMutex;

    QMap<QString, QTPluginStruct> mPluginMap;
    QMutex                                        mDataMutex;
    bool                                              mUnloadPluginWhenDisable = true;
    // 插件独立运行相关
    QMap<QString, AppLauncher*>        mPluginLauncherMap;
    QMutex                                                        mLauncherMutex;
    //
    bool                                                              mIsAboutExit = false;
    //插件加载模式
    PluginLoadMode                                       mLoadMode = Plugin_Load_Orinal;
};

#endif // QTPLUGINMANAGE_H
