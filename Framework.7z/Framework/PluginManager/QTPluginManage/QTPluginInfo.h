﻿/*****************************************************
** 文件名：QTluginStruct.h
** 版 本：v.1.0
** 内容简述：QT插件界面信息结构体
** 创建日期： 2021.11.18
** 创建人：孙伟伟
** 修改记录：1.0
日期:2021.11.18  版本:v.1.0    修改人:孙伟伟   修改内容:创建
*****************************************************/
#ifndef QTPLUGININFO_H
#define QTPLUGININFO_H

#include <QString>
#include "FunctionPage/OpenPluginInfo.h"
#include <QObject>
///
/// \brief qt插件信息结构体
///
struct QTPluginStruct : public OpenPluginStruct
{
public:
    QTPluginStruct() : OpenPluginStruct()
    {
        type = Plugin_Type_Qt;
        widget = nullptr;
    }

    QTPluginStruct(const QDomElement& e) : OpenPluginStruct(e)
    {
        widget = nullptr;
        type = Plugin_Type_Qt;
    }


//    static PluginDataPtrList parseQtPluginFromXmlNodeList(const QDomNodeList& nodes)
//    {
//        PluginDataPtrList list;
//        for(int i=0; i<nodes.size(); i++)
//        {
//            QDomElement ele = nodes.at(i).toElement();
//            if(ele.isNull()) continue;
//            list.append(new QTPluginStruct(ele));
//        }
//        return list;
//    }

public:
    QWidget*            widget;

};

Q_DECLARE_METATYPE(QTPluginStruct)

#endif // QTPLUGININFO_H
