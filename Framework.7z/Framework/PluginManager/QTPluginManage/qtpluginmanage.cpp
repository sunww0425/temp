﻿/*****************************************************
** 文件名：QTPluginManage.cpp
** 版 本：v.1.0
** 内容简述：QT插件管理类
** 创建日期： 2021.11.17
** 创建人：孙伟伟
** 修改记录：1.0
日期:2021.11.17  版本:v.1.0    修改人:孙伟伟   修改内容:创建
*****************************************************/
#include "qtpluginmanage.h"
#include <QDomDocument>
#include <QApplication>
#include <QFile>
#include <QDebug>
#include <QFileInfo>
#include <QLibrary>
#include <QJsonObject>
#include <QJsonDocument>
#include <QMapIterator>
#include "FunctionPage/pluginmanager.h"
#include "pluginutils.h"
#include <QPluginLoader>

QTPluginManage* QTPluginManage::mInstance = nullptr;
QMutex  QTPluginManage::mInsMutex;

QTPluginManage* QTPluginManage::instance()
{
    if(mInstance == nullptr)
    {

        QMutexLocker locker(&mInsMutex);
        if(mInstance == nullptr) mInstance = new QTPluginManage();
    }

    return mInstance;
}

QTPluginManage::QTPluginManage(QObject *parent) : QObject(parent)
{
    qRegisterMetaType<QTPluginStruct>("const QTPluginStruct&");
    qRegisterMetaType<QList<QTPluginStruct>>("const QList<QTPluginStruct>&");
    connect(PluginManager::instance(), SIGNAL(signalSendQtPluginList(QList<QTPluginStruct>)),
            this, SLOT(slotLoadPluginList(QList<QTPluginStruct>)));
}

void QTPluginManage::stop()
{
    PluginManager::instance()->writeLogInfo(QStringLiteral("Qt插件管理器设定为插件主动关闭模式..."));
    setIsAboutClose(true);
    //停止所有的插件运行
    QStringList list = getAllLaunchers();
    PluginManager::instance()->writeLogInfo(QStringLiteral("Qt插件管理器需要停止的插件id:%1").arg(list.join(",")));
    foreach (QString id, list)
    {
        QString errorMsg;
        stopPlugin(id, errorMsg);
    }
}

void QTPluginManage::repairIconResourcePath()
{
    if(mPluginMap.size() == 0) return ;
    foreach (QString key, mPluginMap.keys())
    {
        QTPluginStruct& info = mPluginMap[key];
        if(info.adjustIconPath())
        {
            PluginManager::instance()->saveConfig(&info);
        }
    }
    return ;
}
///
/// \brief 读取第三方插件信息
void QTPluginManage::slotLoadPluginList(const QList<QTPluginStruct>& list)
{
    PluginManager::instance()->writeLogInfo(QStringLiteral("Qt插件管理器开始初始化: 插件数:%1").arg(list.size()));
    QString errorMsg;
    mPluginMap.clear();
    foreach (QTPluginStruct info, list)
    {
        mPluginMap.insert(info.id, info);
    }
    repairIconResourcePath();

    emit signalSendPluginList(mPluginMap.values());

    if(mPluginMap.count() > 0)
    {
        PluginManager::instance()->appendPluginID(mPluginMap.keys());
        //根据插件的状态,启用插件
        foreach (QString key, mPluginMap.keys())
        {
            QTPluginStruct& info = mPluginMap[key];
            if(info.state == Plugin_State_Started)
            {
                errorMsg.clear();                
                PluginManager::instance()->writeLogInfo(QStringLiteral("Qt插件%1(%2)的状态为启动,开始启用插件. %3")
                                                        .arg(info.id).arg(info.name).arg(errorMsg));
                startPlugin(info.id, errorMsg);
            }
        }
    }
    emit signalPluginInitFinished();
}

bool QTPluginManage::addPlugin(const QTPluginStruct &info, QString& errorMsg)
{
    bool isOk = false;
    if(1)
    {
        QMutexLocker locker(&mDataMutex);
        if(mPluginMap.contains(info.id))
        {
            errorMsg = QStringLiteral("当前插件id已存在");
            return false;
        }
        mPluginMap.insert(info.id, info);
        if(PluginManager::instance()->saveConfig(&(mPluginMap[info.id])))
        {
            isOk = true;
        } else
        {
            errorMsg = QStringLiteral("保存插件信息到配置文件失败");
            mPluginMap.remove(info.id);
        }
    }
    if(isOk)
    {
        PluginManager::instance()->appendPluginID(info.id);
        emit signalEditPluginSuccess(info);
    }
    return isOk;
}

bool QTPluginManage::modifyPlugin(const QTPluginStruct &info, QString &errorMsg)
{
    bool isOk = false;
    if(1)
    {
        QMutexLocker locker(&mDataMutex);
        if(!mPluginMap.contains(info.id))
        {
            errorMsg = QStringLiteral("当前插件id不存在");
            return false;
        }
        QTPluginStruct old_info = mPluginMap.value(info.id);
        mPluginMap.insert(info.id, info);
        if(PluginManager::instance()->saveConfig(&(mPluginMap[info.id])))
        {
            isOk = true;
        } else
        {
            mPluginMap.insert(info.id, old_info);
            errorMsg = QStringLiteral("保存插件信息到配置文件失败");
        }
    }
    if(isOk)  emit signalEditPluginSuccess(info);
    return isOk;
}

bool QTPluginManage::deletePlugin(const QString &id, QString& errorMsg)
{
    bool isOk = false;
    if(1)
    {
        QMutexLocker locker(&mDataMutex);
        if(!mPluginMap.contains(id))
        {
            errorMsg = QStringLiteral("当前插件id不存在");
            return false;
        }
        QTPluginStruct info = mPluginMap.take(id);
        if(PluginManager::instance()->deletePlugin(&info))
        {
            isOk = true;
        } else
        {
            mPluginMap.insert(id, info);
            errorMsg = QStringLiteral("保存插件信息到配置文件失败");
        }
    }
    if(isOk)
    {
        PluginManager::instance()->removePluginID(id);
        emit signalStopPlugin(id);
        emit signalDelPluginSuccess(id);
    }
    return isOk;
}

bool QTPluginManage::updatePluginState(const QString &id, PluginState state, QString& errorMsg)
{
    bool isOk = false;
    if(1)
    {
        QMutexLocker locker(&mDataMutex);
        if(!mPluginMap.contains(id))
        {
            errorMsg = QStringLiteral("当前插件id不存在");
            return false;
        }
        QTPluginStruct old_info = mPluginMap[id];
        if(old_info.state == state) return true;

        mPluginMap[id].state = state;
        if(PluginManager::instance()->saveConfig(&(mPluginMap[id])))
        {
            isOk = true;
        } else
        {
            mPluginMap.insert(id, old_info);
            errorMsg = QStringLiteral("保存插件信息到配置文件失败");
        }
    }
    if(isOk)
    {
        emit signalEditPluginSuccess(mPluginMap[id]);
        if(state == Plugin_State_Started)
        {
            //将插件对应的widget重新赋值
            QTPluginStruct& info = mPluginMap[id];
            if(mLoadMode == Plugin_Load_Orinal)
            {
                info.widget = PluginManager::instance()->getPluginWidget(info.url, errorMsg);
                appendLauncher(info.id, nullptr);
                emit signalStartPlugin(info);
            } else
            {
                startPluginWithLauncher(info);
            }
        } else
        {
            emit signalStopPlugin(id);
        }
    }
    return isOk;
}

bool QTPluginManage::getPluginWithId(const QString &id, QTPluginStruct &info)
{
    qDebug()<<"try get mutex locker...";
    QMutexLocker locker(&mDataMutex);
    qDebug()<<"try get mutex locker end...";
    if(!mPluginMap.contains(id)) return false;
    info = mPluginMap.value(id);
    return true;
}

bool QTPluginManage::startPlugin(const QString& id,  QString& errorMsg)
{
    qDebug()<<"start plugin:"<<id<<"with mode:"<<mLoadMode;
    QTPluginStruct info;
    if(!getPluginWithId(id, info))
    {
        errorMsg = QStringLiteral("当前id[%1]对应的插件不存在").arg(id);
        return false;
    }
    PluginManager::instance()->writeLogInfo(QStringLiteral("开始启动插件.id:%1, 名称:%2, url:%3").arg(info.id).arg(info.name).arg(info.url));

    qDebug()<<"plugin start mode:"<<mLoadMode;
    if(info.state == Plugin_State_Started)
    {
        if(mLoadMode == Plugin_Load_Orinal)
        {
            //将插件对应的widget重新赋值
            info.widget = PluginManager::instance()->getPluginWidget(info.url, errorMsg);
            appendLauncher(info.id, nullptr);
            emit signalStartPlugin(info);
            return errorMsg.size() == 0;
        } else
        {
            qDebug()<<"start qt outer:"<<info.id<<info.name;
            return startPluginWithLauncher(info);
        }
    } else
    {
        return updatePluginState(info.id, Plugin_State_Started, errorMsg);
    }

    return true;
}

bool QTPluginManage::startPluginWithLauncher(const QTPluginStruct &plugin)
{
    if(getLauncherOfId(plugin.id)) return true;
    PluginManager::instance()->writeLogInfo(QStringLiteral("Qt插件管理器启动插件%1(%2)").arg(plugin.id).arg(plugin.name));
    AppLaunchParam param;
    param.mId = plugin.id;
    param.mName = plugin.name;
    param.mUrl = plugin.url;
    param.mType = plugin.type;
    param.mTarget = plugin.id;
    AppLauncher* launcher = new AppLauncher(param, this);
    connect(launcher, SIGNAL(signalSendWindId(QString,qint64)), this, SLOT(slotRecvPluginWId(QString,qint64)));
    connect(launcher, SIGNAL(signalPluginEnd(QString)), this,  SLOT(slotRecvPluginLauncherEnd(QString)));
    connect(launcher, SIGNAL(signalSendLogMsg(QtMsgType, QString, QString)), this, SIGNAL(signalSendLogMsg(QtMsgType,QString,QString)));
    launcher->start();
    appendLauncher(plugin.id, launcher);
    return true;
}

bool QTPluginManage::stopPlugin(const QString& id, QString& errorMsg)
{
    PluginManager::instance()->writeLogInfo(QStringLiteral("开始停止插件[%1]").arg(id));
    QTPluginStruct info;
    if(!getPluginWithId(id, info))
    {
        errorMsg = QStringLiteral("当前id[%1]对应的插件不存在").arg(id);
        PluginManager::instance()->writeLogInfo(QStringLiteral("停止插件[%1]失败.%2").arg(id).arg(errorMsg));
        return false;
    }
    if(info.state == Plugin_State_Stopped)
    {
        errorMsg = QStringLiteral("当前id[%1]对应的插件已经被禁用").arg(id);
        PluginManager::instance()->writeLogInfo(QStringLiteral("停止插件[%1]失败.%2").arg(id).arg(errorMsg));
        return false;
    }
    //卸载插件
    if(!PluginManager::instance()->unLoadPlugin(info.url))
    {
        errorMsg = QStringLiteral("卸载插件[%1]时发生错误").arg(id);
        PluginManager::instance()->writeLogInfo(QStringLiteral("停止插件[%1]失败.%2").arg(id).arg(errorMsg));
        return false;
    }

    AppLauncher* launcher = getLauncherOfId(id);
    if(launcher)
    {
        delete launcher;
        launcher = nullptr;
    }
    removeLanuncher(id);
    if(!mIsAboutExit)
    {
        //不是主动关闭客户端的情况,更新插件状态的信息
        //设定插件的状态
        if(updatePluginState(id, Plugin_State_Stopped, errorMsg))
        {
            PluginManager::instance()->writeLogInfo(QStringLiteral("停止插件[%1]成功").arg(id));
            return true;
        }
    } else
    {
        emit signalStopPlugin(id);
    }

    PluginManager::instance()->writeLogInfo(QStringLiteral("停止插件[%1]成功.%2").arg(id).arg(errorMsg));
    return false;
}

bool QTPluginManage::loadPlugin(const QString &filepath, QTPluginStruct& dest, QString& errorMsg)
{
    ///判断插件是否存在
    //检查是否为相对路径,如果是补足为绝对路径
    QString workPath = filepath;
    if(!workPath.contains("Plugins")) workPath.insert(0, "Plugins/");
    if(!QLibrary::isLibrary(workPath))
    {
        errorMsg = QStringLiteral("插件[%1]不存在").arg(workPath);
        PluginManager::instance()->writeLogError(errorMsg);
        return false;
    }
    ///插件加载
    QPluginLoader loader(workPath);
    ///判断插件加载状态
    if(!loader.load())
    {
        errorMsg = QStringLiteral("插件[%1]加载失败:%2").arg(workPath).arg(loader.errorString());
        PluginManager::instance()->writeLogError(errorMsg);
        return false;
    }

    ///插件接口实例化
    PluginInterface *plugin=qobject_cast<PluginInterface*>(loader.instance());
    if(!plugin)
    {
        errorMsg = QStringLiteral("插件[%1]实例化失败").arg(workPath);
        PluginManager::instance()->writeLogError(errorMsg);
        return false;
    }
    //获取插件的信息
    std::string JsonStr;
    plugin->Get_PluginInfo(JsonStr);
    ///将插件信息转换车门成QJsonDocument
    QJsonDocument doc = QJsonDocument::fromJson(QByteArray::fromStdString(JsonStr));
    if(!doc.isObject())
    {
        errorMsg = QStringLiteral("插件信息Json格式错误");
        PluginManager::instance()->writeLogError(errorMsg);
        return false;
    }
    QJsonObject obj = doc.object();
    //临时存储QT插件结构体
    dest.id = obj.value("PluginID").toString();
    dest.name=obj.value("PluginName").toString();
    dest.type = Plugin_Type_Qt;
    dest.icon_path.clear();
    dest.version = obj.value("PluginVersion").toString();
    dest.describe = obj.value("PluginDescribe").toString();
    QByteArray bytes = QByteArray::fromBase64(obj.value("PluginIcon").toString().toLatin1());
    if(bytes.size() > 0)
    {
        //保存图片到当前目录下的Images目录
        PluginUtils::savePluginNativeIcon(bytes, dest.id, dest.icon_path);
    }
    if(dest.icon_path.size() == 0)
    {
        dest.icon_path = "Images/QTPlugin.png";
    }
    if(dest.id.isEmpty() || dest.name.isEmpty())
    {
        errorMsg = QStringLiteral("插件信息异常.id(%1),名称(%2)").arg(dest.id).arg(dest.name);
        PluginManager::instance()->writeLogWarning(errorMsg);
    } else
    {
        PluginManager::instance()->writeLogInfo(QStringLiteral("插件[%1]加载成功").arg(workPath));
    }
    QString common_path = QString("%1/Plugins/").arg(QApplication::applicationDirPath());
    int index = filepath.indexOf(common_path);
    if(index >= 0)
    {
        dest.url = filepath.mid(index + common_path.length());
    } else
    {
        dest.url = filepath;
    }
    dest.state = Plugin_State_Stopped;
    return true;
}

bool QTPluginManage::unloadPlugin(const QString &path)
{
   return PluginManager::instance()->unLoadPlugin(path);
}

bool QTPluginManage::isPluginIdExist(const QString &id)
{
    return PluginManager::instance()->isIdExist(id);
}

void QTPluginManage::reloadPluginWindow(const QString &id)
{
    PluginManager::instance()->writeLogInfo(QStringLiteral("Qt插件管理器重新获取插件%1窗口").arg(id));
    AppLauncher* launcher = getLauncherOfId(id);
    if(!launcher) return;
    launcher->findWindow();
}

void QTPluginManage::appendLauncher(const QString &id, AppLauncher *launcher)
{
    QMutexLocker locker(&mLauncherMutex);
    mPluginLauncherMap.insert(id, launcher);
}

void QTPluginManage::removeLanuncher(const QString &id)
{
    QMutexLocker locker(&mLauncherMutex);
    mPluginLauncherMap.remove(id);
}

AppLauncher* QTPluginManage::getLauncherOfId(const QString &id)
{
    QMutexLocker locker(&mLauncherMutex);
    return mPluginLauncherMap.value(id, nullptr);
}

QStringList QTPluginManage::getAllLaunchers()
{
    QMutexLocker locker(&mLauncherMutex);
    return mPluginLauncherMap.keys();
}

//接收到插件启动器返回的插件窗口id
void QTPluginManage::slotRecvPluginWId(const QString &pluginId, qint64 wid)
{
    QTPluginStruct plugin = mPluginMap.value(pluginId);
    PluginManager::instance()->writeLogInfo(QStringLiteral("Qt插件管理器收到插件启动器返回的窗口信息. 插件:%1(%2), 窗口:%3")
                          .arg(plugin.id).arg(plugin.name).arg(wid));

    //通知主界面显示当前插件的窗口
    emit signalStartPlugin(plugin, wid);
}

//接收到插件程序结束的情况
void QTPluginManage::slotRecvPluginLauncherEnd(const QString &id)
{
    PluginManager::instance()->writeLogInfo(QStringLiteral("Qt插件管理器收到插件启动器返回插件%1结束信息").arg(id));
    if(!mIsAboutExit)
    {
        PluginManager::instance()->writeLogInfo(QStringLiteral("更新插件%1状态为结束").arg(id));
        QString errorMsg;
        updatePluginState(id, Plugin_State_Stopped, errorMsg);
    }
}
