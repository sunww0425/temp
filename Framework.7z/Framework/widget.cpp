﻿#include "widget.h"
#include "ui_widget.h"

#include <QMenu>
#include <QTimer>
#include "pluginmanager.h"
#include "pluginutils.h"
#include "PluginManager/QTPluginManage/qtpluginmanagegui.h"
#include "PluginManager/WebPluginManage/webpluginmanagegui.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    //初始化标题栏
    initTitleBar();

    //一次性延时启动处理一些东西
    QTimer::singleShot(100, this, SLOT(delayStart()));
}

Widget::~Widget()
{
    delete ui;
}

///
/// \brief 初始化标题栏
///
void Widget::initTitleBar()
{
    this->setWindowFlags(Qt::FramelessWindowHint);
    //最小化图标
    ui->MinBtn->setIcon(QIcon(":/Image/iconMin.png"));
    //最大化图标
    ui->MaxBtn->setIcon(QIcon(":/Image/iconRestore.png"));
    //关闭图标
    ui->CloseBtn->setIcon(QIcon(":/Image/iconClose.png"));
    //连接信号槽
    //最小化
    connect(ui->MinBtn, &QToolButton::clicked, this, [this]()
    {
        this->showMinimized();
    });

    //最大/还原
    connect(ui->MaxBtn, &QToolButton::clicked, this, [this]()
    {
        if(this->windowState() & Qt::WindowMaximized)
        {
            this->showNormal();
        }
        else
        {
            this->showMaximized();
        }
    });

    //关闭
    connect(ui->CloseBtn, &QToolButton::clicked, this, [this]()
    {
        this->close();
    });

    ui->PluginManageBtn->setIconSize(QSize(15,15));
    ui->PluginManageBtn->setIcon(QIcon(":/Image/Menu.png"));

    //添加插件管理的几个页面
    initPluginManagerTab(PluginManager_Qt, "QtPluginManage", QStringLiteral("标准插件集成管理"));
    initPluginManagerTab(PluginManager_Web, "WebPluginManage", QStringLiteral("浏览器插件集成管理"));
    initPluginManagerTab(PluginManager_Log, "LogPluginManage", QStringLiteral("插件监控管理"));
}

///
/// \brief 延迟启动
///
void Widget::delayStart()
{
    QString errorMsg;
    if(!PluginManager::instance()->loadConfig(errorMsg))
    {
        PluginUtils::warningMsgBox(errorMsg);
        return;
    }

    //设置标题
    setWindowTitle(QString("%1").arg(PluginManager::instance()->getAppTitle()));
    ui->Titlelabel->setText(this->windowTitle());

    PluginStatusMonitor::instance()->appendProcess(qApp->applicationPid(),  PluginManager::instance()->getFrameWorkLogId(),ui->Titlelabel->text());

    QString iconPath = PluginUtils::getFullIconPath(PluginManager::instance()->getAppIconPath());
    QPixmap pix;
    QFileInfo iconfile(iconPath);
    if(iconfile.exists())
    {
        pix = QPixmap(iconPath);
    }
    else
    {
        //默认图标
        pix = QPixmap(":/Image/PluginManageIcon.png");
    }
    //设置界面大标题图标
    this->setWindowIcon(QIcon(iconPath));

    pix.scaled(ui->SystemIcon->size(),Qt::KeepAspectRatio,Qt::SmoothTransformation);
    ui->SystemIcon->setScaledContents(true);
    ui->SystemIcon->setPixmap(pix);
}

///
/// \brief 点击插件管理按钮
///
void Widget::on_PluginManageBtn_clicked()
{
    QMenu *cmenu = new QMenu(ui->PluginManageBtn);
    cmenu->setStyleSheet("background-color:rgb(224, 227, 232);color:black;border:0px solid;selection-background-color:rgb(226, 234, 253);selection-color:blue;");
    QAction *action_QT = new QAction(QIcon(":/Image/Dtag.ico"),QStringLiteral("标准插件集成管理"));
    action_QT->setData(PluginManager_Qt);
    QAction *action_WEB = new QAction(QIcon(":/Image/Wtag.ico"),QStringLiteral("浏览器插件集成管理"));
    action_WEB->setData(PluginManager_Web);
    QAction *action_Log = new QAction(QIcon(":/Image/research.png"),QStringLiteral("插件监控管理"));
    action_Log->setData(PluginManager_Log);
    cmenu->addAction(action_QT);
    cmenu->addAction(action_WEB);
    cmenu->addAction(action_Log);
    connect(action_QT, SIGNAL(triggered(bool)), this, SLOT(slotManagerMenuClicked()));
    connect(action_WEB, SIGNAL(triggered(bool)), this, SLOT(slotManagerMenuClicked()));
    connect(action_Log, SIGNAL(triggered(bool)),this,SLOT(slotManagerMenuClicked()));

    cmenu->exec(QCursor::pos());
    delete action_QT;
    delete action_WEB;
    delete action_Log;

    delete cmenu;
}

///
/// \brief 插件管理菜单点击
///
void Widget::slotManagerMenuClicked()
{
    QAction *act = qobject_cast<QAction*>(sender());
    if(!act) return;
    //根据菜单项绑定的数据获取对应的管理页面
    int type = act->data().toInt();
    for(int i=0;i<ui->stackedWidget->count();i++)
    {
        if(ui->stackedWidget->widget(i) && ui->stackedWidget->widget(i)->property("manager_type").toInt() == type)
        {
            ui->stackedWidget->setCurrentIndex(i);
            break;
        }
    }
}

///
/// \brief 初始化插件管理菜单及其页面
/// \param type 类型
/// \param name_en 标签英文名称
/// \param name_ch 标签中文名称
///
void Widget::initPluginManagerTab(int type, const QString &name_en, const QString &name_ch)
{
    //根据不同的类型创建显示的widget
    QWidget* dest = nullptr;
    if (type == PluginManager_Qt)
    {
        dest = new QTPluginManageGUI(this);
        qobject_cast<QTPluginManageGUI*>(dest)->setTitle(name_ch);
    }
    else if (type == PluginManager_Web)
    {
        dest = new WebPluginManageGUI(this);
        qobject_cast<WebPluginManageGUI*>(dest)->setTitle(name_ch);
    }
    else if (type == PluginManager_Log)
    {
        //dest = mLogForm;
    }

    if(!dest) return;

    //初始化标签内部的widget区域
    dest->setProperty("manager_type", type);
    dest->setObjectName(name_en);

    //设置标签名称
    if(ui->stackedWidget->indexOf(dest) < 0)
    {
        ui->stackedWidget->addWidget(dest);
    }
}
