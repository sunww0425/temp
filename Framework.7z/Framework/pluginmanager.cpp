#include "pluginmanager.h"

PluginManager *PluginManager::instance()
{
    if(!m_Instance)
    {
        QMutexLocker locker(&m_InsMutex);
        if(!m_Instance)
        {
            m_Instance = new PluginManager;
        }
    }
    return m_Instance;
}

PluginManager::PluginManager(QObject *parent) : QObject(parent)
{

}
