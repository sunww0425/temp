#ifndef PLUGINMANAGER_H
#define PLUGINMANAGER_H

#include <QMutex>
#include <QObject>
#include "openpluginstruct.h"

class QPluginLoader;

struct AppConfig
{
    QString mTitle;
    QString mId;
    QString mIconPath;
    QString mTaskMode;
    int  mQtPluginLoadMode = Plugin_Load_Orinal;
    int  mWebPluginLoadMode = Plugin_Load_Orinal;
    int  mAppPluginEmbeddedMode = Plugin_Embed_AutoLayout;
    int  mMaxLogRowCount = 500;

    void initFromXmlNode(const QDomNode& node);

    bool isOK() const
    {
        return !(mTitle.isEmpty() || mId.isEmpty());
    }

    QString iconPath();
    void init()
    {
        mTitle.clear();mId.clear();mIconPath.clear();
    }
    QString toString() const
    {
        return QStringLiteral("Title:%1 ID:%2 Icon:%3").arg(mTitle).arg(mId).arg(mIconPath);
    }
};

class PluginManager : public QObject
{
    Q_OBJECT
public:
    ///
    /// \brief 插件管理类实例化
    /// \return 返回插件管理类
    ///
    static PluginManager *instance();

signals:

private:
    explicit PluginManager(QObject *parent = nullptr);
    static PluginManager * m_Instance;
    static QMutex m_InsMutex;

};

#endif // PLUGINMANAGER_H
